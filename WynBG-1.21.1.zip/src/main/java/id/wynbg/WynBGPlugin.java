package id.wynbg;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.WeatherType;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;

public class WynBGPlugin extends JavaPlugin {

    public enum DropMode {
        SOLO,
        SQUAD
    }

    private ParachuteManager parachuteManager;
    private BriefingManager briefingManager;
    private PodiumManager podiumManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.parachuteManager = new ParachuteManager(this);
        this.briefingManager = new BriefingManager(this, parachuteManager);
        this.podiumManager = new PodiumManager(this);

        getServer().getPluginManager().registerEvents(
                new DropListener(this, briefingManager, parachuteManager, podiumManager), this
        );

        WynBGCommand cmd = new WynBGCommand(this, briefingManager, podiumManager);
        if (getCommand("wynbg") != null) {
            getCommand("wynbg").setExecutor(cmd);
            getCommand("wynbg").setTabCompleter(cmd);
        }

        getLogger().info("WynBG (Void Drop + Vanilla Klasemen & Podium Loncat) aktif di Paper 1.21.1!");
    }

    @Override
    public void onDisable() {
        if (briefingManager != null) {
            briefingManager.cleanup();
        }
        if (parachuteManager != null) {
            parachuteManager.cleanupAll();
        }
        if (podiumManager != null) {
            podiumManager.cleanup();
        }
    }

    public Location getConfigLocation(String path) {
        String worldName = getConfig().getString(path + ".world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            world = Bukkit.getWorlds().getFirst();
        }
        double x = getConfig().getDouble(path + ".x", 0.5);
        double y = getConfig().getDouble(path + ".y", 100.0);
        double z = getConfig().getDouble(path + ".z", 0.5);
        float yaw = (float) getConfig().getDouble(path + ".yaw", 0.0);
        float pitch = (float) getConfig().getDouble(path + ".pitch", 0.0);
        return new Location(world, x, y, z, yaw, pitch);
    }

    public void saveConfigLocation(String path, Location loc) {
        getConfig().set(path + ".world", loc.getWorld().getName());
        getConfig().set(path + ".x", loc.getX());
        getConfig().set(path + ".y", loc.getY());
        getConfig().set(path + ".z", loc.getZ());
        getConfig().set(path + ".yaw", loc.getYaw());
        getConfig().set(path + ".pitch", loc.getPitch());
        saveConfig();
    }

    // =========================================================================
    // PARACHUTE & LANDING VFX MANAGER
    // =========================================================================
    private static class ParachuteManager {

        private final WynBGPlugin plugin;
        private final MiniMessage mm = MiniMessage.miniMessage();
        private final Set<UUID> parachutingPlayers = new HashSet<>();
        private final Set<UUID> landingGracePlayers = new HashSet<>();
        private final Map<UUID, ItemStack> savedChestplates = new HashMap<>();

        public ParachuteManager(WynBGPlugin plugin) {
            this.plugin = plugin;
            startParachuteAndLandingWatcher();
        }

        public void deployWithParachute(Player player, Location dropLocation) {
            UUID uuid = player.getUniqueId();
            player.teleport(dropLocation);
            player.setFallDistance(0f);

            ItemStack currentChest = player.getInventory().getChestplate();
            if (currentChest != null && currentChest.getType() != Material.AIR) {
                savedChestplates.put(uuid, currentChest.clone());
            }

            ItemStack parachute = new ItemStack(Material.ELYTRA);
            ItemMeta meta = parachute.getItemMeta();
            if (meta != null) {
                meta.displayName(mm.deserialize("<aqua><bold>Parasut Taktis"));
                meta.setUnbreakable(true);
                parachute.setItemMeta(meta);
            }

            player.getInventory().setChestplate(parachute);
            player.setGliding(true);
            parachutingPlayers.add(uuid);

            Title whiteFlash = Title.title(
                    mm.deserialize("<white>████████████████████"),
                    mm.deserialize("<white>████████████████████"),
                    Title.Times.times(Duration.ofMillis(80), Duration.ofMillis(220), Duration.ofMillis(450))
            );
            player.showTitle(whiteFlash);

            player.playSound(dropLocation, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.0f, 1.1f);
            player.playSound(dropLocation, Sound.ITEM_ELYTRA_FLYING, 1.0f, 1.0f);
            player.sendActionBar(mm.deserialize("<aqua>Parasut terbuka! Arahkan pandangan untuk mendarat."));
        }

        private void startParachuteAndLandingWatcher() {
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (parachutingPlayers.isEmpty()) return;

                    Iterator<UUID> iterator = parachutingPlayers.iterator();
                    while (iterator.hasNext()) {
                        UUID uuid = iterator.next();
                        Player player = Bukkit.getPlayer(uuid);
                        if (player == null || !player.isOnline()) {
                            iterator.remove();
                            savedChestplates.remove(uuid);
                            continue;
                        }

                        Location trailLoc = player.getLocation().add(0, 0.8, 0);
                        player.getWorld().spawnParticle(Particle.FIREWORK, trailLoc, 3, 0.25, 0.25, 0.25, 0.02);
                        player.getWorld().spawnParticle(Particle.END_ROD, trailLoc, 2, 0.2, 0.2, 0.2, 0.01);

                        if (player.isOnGround() || player.isInWater()) {
                            iterator.remove();
                            completeLanding(player);
                        }
                    }
                }
            }.runTaskTimer(plugin, 2L, 2L);
        }

        private void completeLanding(Player player) {
            UUID uuid = player.getUniqueId();
            player.setGliding(false);
            player.setFallDistance(0f);

            ItemStack previousChest = savedChestplates.remove(uuid);
            player.getInventory().setChestplate(previousChest);

            landingGracePlayers.add(uuid);
            Bukkit.getScheduler().runTaskLater(plugin, () -> landingGracePlayers.remove(uuid), 60L);

            player.playSound(player.getLocation(), Sound.ITEM_ARMOR_EQUIP_LEATHER, 1.0f, 1.1f);
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.9f, 1.3f);
            player.sendActionBar(mm.deserialize("<green><bold>MENDARAT! <gray>Segera cari perlengkapan."));

            spawnLandingShockwaveRing(player.getLocation());
        }

        private void spawnLandingShockwaveRing(Location center) {
            World world = center.getWorld();
            Particle.DustOptions whiteDust = new Particle.DustOptions(Color.WHITE, 1.2f);
            Particle.DustOptions limeDust = new Particle.DustOptions(Color.fromRGB(110, 255, 110), 1.1f);

            new BukkitRunnable() {
                int step = 0;

                @Override
                public void run() {
                    if (step > 10) {
                        cancel();
                        return;
                    }

                    double radius = 0.6 + (step * 0.22);
                    int points = 24;
                    for (int i = 0; i < points; i++) {
                        double angle = (2 * Math.PI * i) / points;
                        double x = Math.cos(angle) * radius;
                        double z = Math.sin(angle) * radius;
                        Location ringLoc = center.clone().add(x, 0.15, z);

                        world.spawnParticle(Particle.DUST, ringLoc, 1, 0, 0, 0, 0, whiteDust);
                        if (i % 3 == 0) {
                            world.spawnParticle(Particle.DUST, ringLoc.clone().add(0, 0.1, 0), 1, 0, 0, 0, 0, limeDust);
                        }
                    }

                    if (step % 2 == 0) {
                        world.spawnParticle(Particle.FIREWORK, center.clone().add(0, 1.0, 0), 6, 0.6, 0.8, 0.6, 0.03);
                    }

                    step++;
                }
            }.runTaskTimer(plugin, 0L, 2L);
        }

        public boolean isParachuting(UUID uuid) {
            return parachutingPlayers.contains(uuid);
        }

        public boolean hasLandingGrace(UUID uuid) {
            return landingGracePlayers.contains(uuid);
        }

        public void cleanupPlayer(Player player) {
            UUID uuid = player.getUniqueId();
            if (parachutingPlayers.remove(uuid)) {
                player.getInventory().setChestplate(savedChestplates.remove(uuid));
            }
            landingGracePlayers.remove(uuid);
        }

        public void cleanupAll() {
            for (UUID uuid : new HashSet<>(parachutingPlayers)) {
                Player player = Bukkit.getPlayer(uuid);
                if (player != null) {
                    cleanupPlayer(player);
                }
            }
            parachutingPlayers.clear();
            savedChestplates.clear();
            landingGracePlayers.clear();
        }
    }

    // =========================================================================
    // VOID BRIEFING & CINEMATIC DEPLOYMENT MANAGER (20s + GLOWING)
    // =========================================================================
    private static class BriefingManager {

        private record QueuedBatch(List<UUID> playerIds, DropMode mode) {}

        private final WynBGPlugin plugin;
        private final ParachuteManager parachuteManager;
        private final MiniMessage mm = MiniMessage.miniMessage();

        private final Queue<QueuedBatch> waitingQueue = new LinkedList<>();
        private final Set<UUID> frozenPlayers = new HashSet<>();
        private final Set<UUID> risingReleasePlayers = new HashSet<>();
        private final Map<UUID, Boolean> previousAllowFlight = new HashMap<>();
        private final Map<UUID, BossBar> activeBossBars = new HashMap<>();
        private final List<ItemDisplay> activeDisplays = new ArrayList<>();
        private boolean briefingOccupied = false;

        public BriefingManager(WynBGPlugin plugin, ParachuteManager parachuteManager) {
            this.plugin = plugin;
            this.parachuteManager = parachuteManager;
            startQueueNotifier();
        }

        public void enqueueDeployment(List<Player> players, DropMode mode) {
            List<UUID> ids = players.stream().map(Player::getUniqueId).toList();
            if (ids.isEmpty()) return;

            if (briefingOccupied) {
                Location queueLoc = plugin.getConfigLocation("locations.queue");
                for (Player p : players) {
                    prepareVoidStasis(p, queueLoc, 20 * 120);
                }
                waitingQueue.add(new QueuedBatch(ids, mode));
            } else {
                runBriefingSession(ids, mode);
            }
        }

        private void prepareVoidStasis(Player player, Location loc, int durationTicks) {
            UUID uuid = player.getUniqueId();
            frozenPlayers.add(uuid);
            risingReleasePlayers.remove(uuid);

            previousAllowFlight.putIfAbsent(uuid, player.getAllowFlight());
            player.setAllowFlight(true);
            player.setFlying(true);
            player.setFallDistance(0f);
            player.teleport(loc);

            player.setGlowing(true);
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.GLOWING, durationTicks, 0, false, false, false
            ));
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.BLINDNESS, durationTicks, 1, false, false, false
            ));
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.DARKNESS, durationTicks, 0, false, false, false
            ));
            player.setPlayerTime(18000L, false);
            player.setPlayerWeather(WeatherType.CLEAR);
        }

        private void restoreNormalState(Player player) {
            UUID uuid = player.getUniqueId();
            frozenPlayers.remove(uuid);
            risingReleasePlayers.remove(uuid);

            BossBar bar = activeBossBars.remove(uuid);
            if (bar != null) {
                player.hideBossBar(bar);
            }

            player.setGlowing(false);
            player.removePotionEffect(PotionEffectType.GLOWING);
            player.removePotionEffect(PotionEffectType.BLINDNESS);
            player.removePotionEffect(PotionEffectType.DARKNESS);
            player.resetPlayerTime();
            player.resetPlayerWeather();

            Boolean wasAllowed = previousAllowFlight.remove(uuid);
            boolean allowFlight = wasAllowed != null && wasAllowed;
            player.setFlying(false);
            player.setAllowFlight(allowFlight);
        }

        private void startQueueNotifier() {
            new BukkitRunnable() {
                int dotStep = 0;

                @Override
                public void run() {
                    if (waitingQueue.isEmpty()) return;
                    dotStep = (dotStep % 3) + 1;
                    String dots = ".".repeat(dotStep);

                    int position = 1;
                    for (QueuedBatch batch : waitingQueue) {
                        Title title = Title.title(
                                mm.deserialize("<yellow><bold>MENUNGGU GILIRAN" + dots),
                                mm.deserialize("<gray>Antrean ke-<white>" + position + " <gray>| Ruang briefing sedang dipakai"),
                                Title.Times.times(Duration.ZERO, Duration.ofMillis(1200), Duration.ZERO)
                        );
                        for (UUID uuid : batch.playerIds()) {
                            Player p = Bukkit.getPlayer(uuid);
                            if (p != null && p.isOnline()) {
                                p.showTitle(title);
                            }
                        }
                        position++;
                    }
                }
            }.runTaskTimer(plugin, 20L, 20L);
        }

        private void runBriefingSession(List<UUID> playerIds, DropMode mode) {
            briefingOccupied = true;
            Location briefingLoc = plugin.getConfigLocation("locations.briefing");
            int deployAtSeconds = Math.max(4, plugin.getConfig().getInt("briefing.deploy-at-seconds", 20));
            int releasePhaseSeconds = Math.min(5, deployAtSeconds - 1);
            int voidTicks = (deployAtSeconds + 2) * 20;

            List<Player> participants = new ArrayList<>();
            for (UUID uuid : playerIds) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    participants.add(p);
                    prepareVoidStasis(p, briefingLoc, voidTicks);

                    BossBar bar = BossBar.bossBar(
                            mm.deserialize("<light_purple>✦ <white>Bersiap Terjun dalam <yellow>00:" + String.format("%02d", deployAtSeconds) + " <light_purple>✦"),
                            1.0f,
                            BossBar.Color.PURPLE,
                            BossBar.Overlay.PROGRESS
                    );
                    p.showBossBar(bar);
                    activeBossBars.put(uuid, bar);
                }
            }

            if (participants.isEmpty()) {
                finishBriefingAndAdvanceQueue();
                return;
            }

            spawnOrbitingGear(briefingLoc);
            startVoidAndNebulaParticles(participants, deployAtSeconds, releasePhaseSeconds);

            ConfigurationSection slidesSec = plugin.getConfig().getConfigurationSection("briefing.slides");

            new BukkitRunnable() {
                int elapsedSeconds = 0;

                @Override
                public void run() {
                    int remaining = Math.max(0, deployAtSeconds - elapsedSeconds);
                    float progress = Math.max(0.0f, Math.min(1.0f, (float) remaining / deployAtSeconds));
                    boolean inReleasePhase = remaining <= releasePhaseSeconds && remaining > 0;

                    for (Player p : participants) {
                        if (!p.isOnline()) continue;
                        if (!p.isGlowing()) {
                            p.setGlowing(true);
                        }
                        BossBar bar = activeBossBars.get(p.getUniqueId());
                        if (bar != null) {
                            bar.progress(progress);
                            if (inReleasePhase) {
                                bar.name(mm.deserialize("<light_purple>✦ <white>Langit Terbuka — Meluncur! <light_purple>✦"));
                            } else {
                                bar.name(mm.deserialize("<light_purple>✦ <white>Bersiap Terjun dalam <yellow>00:"
                                        + String.format("%02d", remaining) + " <light_purple>✦"));
                            }
                        }
                    }

                    if (slidesSec != null) {
                        for (String key : slidesSec.getKeys(false)) {
                            int delay = slidesSec.getInt(key + ".delay-seconds", -1);
                            if (delay == elapsedSeconds) {
                                String rawTitle = slidesSec.getString(key + ".title", "");
                                String rawSub = slidesSec.getString(key + ".subtitle", "")
                                        .replace("{mode}", mode.name());
                                String soundName = slidesSec.getString(key + ".sound", "BLOCK_NOTE_BLOCK_PLING");
                                float pitch = (float) slidesSec.getDouble(key + ".pitch", 1.0);

                                Title title = Title.title(
                                        mm.deserialize(rawTitle),
                                        mm.deserialize(rawSub),
                                        Title.Times.times(Duration.ofMillis(150), Duration.ofSeconds(2), Duration.ofMillis(150))
                                );

                                Sound sound = parseSound(soundName);
                                for (Player p : participants) {
                                    if (!p.isOnline()) continue;
                                    p.showTitle(title);
                                    if (sound != null) {
                                        p.playSound(p.getLocation(), sound, 1.0f, pitch);
                                    }
                                }
                            }
                        }
                    }

                    if (elapsedSeconds >= deployAtSeconds) {
                        clearDisplays();
                        for (Player p : participants) {
                            if (p.isOnline()) {
                                restoreNormalState(p);
                            }
                        }
                        executeDeployment(participants, mode);
                        finishBriefingAndAdvanceQueue();
                        cancel();
                        return;
                    }

                    elapsedSeconds++;
                }
            }.runTaskTimer(plugin, 0L, 20L);
        }

        private void startVoidAndNebulaParticles(List<Player> participants, int deployAtSeconds, int releasePhaseSeconds) {
            int totalTicks = deployAtSeconds * 20;
            int spiralTicks = Math.max(20, (deployAtSeconds - releasePhaseSeconds) * 20);

            Particle.DustOptions whiteTrailDust = new Particle.DustOptions(Color.WHITE, 1.3f);
            Particle.DustOptions purpleDust = new Particle.DustOptions(Color.fromRGB(165, 75, 255), 1.1f);
            Particle.DustOptions nebulaBlueDust = new Particle.DustOptions(Color.fromRGB(35, 75, 210), 1.6f);
            Particle.DustOptions nebulaVioletDust = new Particle.DustOptions(Color.fromRGB(130, 50, 220), 1.4f);

            new BukkitRunnable() {
                int ticks = 0;
                double angle = 0.0;

                @Override
                public void run() {
                    if (ticks >= totalTicks || !briefingOccupied) {
                        cancel();
                        return;
                    }

                    if (ticks < spiralTicks) {
                        double progress = (double) ticks / spiralTicks;
                        double headHeight = 0.1 + (progress * 2.1);

                        for (Player p : participants) {
                            if (!p.isOnline() || !frozenPlayers.contains(p.getUniqueId())) continue;
                            Location base = p.getLocation();
                            World world = base.getWorld();

                            for (int tail = 0; tail < 12; tail++) {
                                double backFraction = tail * 0.045;
                                double yOffset = Math.max(0.05, headHeight - backFraction);
                                double theta = angle - (tail * 0.28);
                                double radius = 0.68;

                                Location pLoc = base.clone().add(
                                        Math.cos(theta) * radius,
                                        yOffset,
                                        Math.sin(theta) * radius
                                );
                                world.spawnParticle(Particle.DUST, pLoc, 1, 0, 0, 0, 0, whiteTrailDust);
                                if (tail == 0) {
                                    world.spawnParticle(Particle.END_ROD, pLoc, 2, 0.03, 0.03, 0.03, 0.005);
                                } else if (tail % 4 == 0) {
                                    world.spawnParticle(Particle.DUST, pLoc, 1, 0.04, 0.04, 0.04, 0, purpleDust);
                                }
                            }
                        }
                    } else {
                        double releaseProgress = (double) (ticks - spiralTicks) / Math.max(1, totalTicks - spiralTicks);
                        double vortexRadius = 1.2 + (releaseProgress * 2.2);

                        for (Player p : participants) {
                            if (!p.isOnline() || !frozenPlayers.contains(p.getUniqueId())) continue;
                            risingReleasePlayers.add(p.getUniqueId());

                            Location risen = p.getLocation().add(0, 0.10, 0);
                            p.teleport(risen);

                            World world = risen.getWorld();
                            int arms = 3;
                            for (int arm = 0; arm < arms; arm++) {
                                double armBaseAngle = angle + ((2 * Math.PI * arm) / arms);
                                for (int step = 1; step <= 6; step++) {
                                    double r = (vortexRadius / 6.0) * step;
                                    double theta = armBaseAngle + (step * 0.35);
                                    double yWave = Math.sin(theta * 2.0) * 0.25 + 0.8;

                                    Location vortexLoc = risen.clone().add(
                                            Math.cos(theta) * r,
                                            yWave,
                                            Math.sin(theta) * r
                                    );
                                    world.spawnParticle(Particle.DUST, vortexLoc, 1, 0.08, 0.08, 0.08, 0, nebulaBlueDust);
                                    if (step % 2 == 0) {
                                        world.spawnParticle(Particle.DUST, vortexLoc.clone().add(0, -0.3, 0), 1, 0.1, 0.1, 0.1, 0, nebulaVioletDust);
                                    }
                                    if (step == 6) {
                                        world.spawnParticle(Particle.FIREWORK, vortexLoc, 1, 0.05, 0.05, 0.05, 0.01);
                                    }
                                }
                            }
                        }
                    }

                    angle += 0.45;
                    ticks += 2;
                }
            }.runTaskTimer(plugin, 0L, 2L);
        }

        private void finishBriefingAndAdvanceQueue() {
            briefingOccupied = false;
            QueuedBatch next = waitingQueue.poll();
            if (next != null) {
                runBriefingSession(next.playerIds(), next.mode());
            }
        }

        private void executeDeployment(List<Player> players, DropMode mode) {
            Location center = plugin.getConfigLocation("locations.arena-center");
            World arenaWorld = center.getWorld();
            int spreadRadius = plugin.getConfig().getInt("deployment.spread-radius", 250);
            int minDistance = plugin.getConfig().getInt("deployment.min-spread-distance", 35);
            int heightOffset = plugin.getConfig().getInt("deployment.drop-height-offset", 120);

            List<int[]> usedAnchorCoords = new ArrayList<>();

            if (mode == DropMode.SOLO) {
                for (Player player : players) {
                    if (!player.isOnline()) continue;
                    findSafeCoordAsync(arenaWorld, center.getBlockX(), center.getBlockZ(), spreadRadius, minDistance, usedAnchorCoords, 0, safeLoc -> {
                        Location dropLoc = safeLoc.clone().add(0.5, heightOffset, 0.5);
                        parachuteManager.deployWithParachute(player, dropLoc);
                    });
                }
            } else {
                List<List<Player>> squads = buildSquads(players);
                double formationRadius = plugin.getConfig().getDouble("deployment.squad-formation-radius", 4.5);

                for (List<Player> squad : squads) {
                    findSafeCoordAsync(arenaWorld, center.getBlockX(), center.getBlockZ(), spreadRadius, minDistance, usedAnchorCoords, 0, anchorLoc -> {
                        int count = squad.size();
                        for (int i = 0; i < count; i++) {
                            Player member = squad.get(i);
                            if (!member.isOnline()) continue;

                            double angle = (2 * Math.PI * i) / Math.max(1, count);
                            double offsetX = (count == 1) ? 0.5 : Math.cos(angle) * formationRadius;
                            double offsetZ = (count == 1) ? 0.5 : Math.sin(angle) * formationRadius;

                            Location memberDropLoc = anchorLoc.clone().add(offsetX, heightOffset, offsetZ);
                            parachuteManager.deployWithParachute(member, memberDropLoc);
                        }
                    });
                }
            }
        }

        private List<List<Player>> buildSquads(List<Player> players) {
            int maxSquadSize = Math.max(1, plugin.getConfig().getInt("deployment.squad-size", 4));
            Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();

            Map<String, List<Player>> teamGroups = new LinkedHashMap<>();
            List<Player> unassigned = new ArrayList<>();

            for (Player p : players) {
                if (!p.isOnline()) continue;
                Team team = scoreboard.getEntryTeam(p.getName());
                if (team != null) {
                    teamGroups.computeIfAbsent(team.getName(), k -> new ArrayList<>()).add(p);
                } else {
                    unassigned.add(p);
                }
            }

            List<List<Player>> result = new ArrayList<>(teamGroups.values());
            Collections.shuffle(unassigned);

            for (int i = 0; i < unassigned.size(); i += maxSquadSize) {
                result.add(unassigned.subList(i, Math.min(i + maxSquadSize, unassigned.size())));
            }
            return result;
        }

        private void findSafeCoordAsync(World world, int centerX, int centerZ, int radius, int minDistance,
                                        List<int[]> usedCoords, int attemptCount, Consumer<Location> callback) {
            int x = centerX + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
            int z = centerZ + ThreadLocalRandom.current().nextInt(-radius, radius + 1);

            for (int attempt = 0; attempt < 15; attempt++) {
                boolean tooClose = false;
                for (int[] existing : usedCoords) {
                    double distSq = Math.pow(existing[0] - x, 2) + Math.pow(existing[1] - z, 2);
                    if (distSq < (double) minDistance * minDistance) {
                        tooClose = true;
                        break;
                    }
                }
                if (!tooClose) break;
                x = centerX + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
                z = centerZ + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
            }

            final int finalX = x;
            final int finalZ = z;

            world.getChunkAtAsync(finalX >> 4, finalZ >> 4).thenAccept(chunk -> {
                int highestY = world.getHighestBlockYAt(finalX, finalZ);
                Material surface = world.getBlockAt(finalX, highestY, finalZ).getType();
                Location candidate = new Location(world, finalX, highestY + 1.0, finalZ);

                if (attemptCount < 15 && (isUnsafeSurface(surface) || !world.getWorldBorder().isInside(candidate))) {
                    findSafeCoordAsync(world, centerX, centerZ, radius, minDistance, usedCoords, attemptCount + 1, callback);
                    return;
                }

                usedCoords.add(new int[]{finalX, finalZ});
                callback.accept(candidate);
            });
        }

        private boolean isUnsafeSurface(Material mat) {
            return mat == Material.WATER
                    || mat == Material.LAVA
                    || mat == Material.MAGMA_BLOCK
                    || mat == Material.FIRE
                    || mat == Material.CAMPFIRE
                    || mat == Material.CACTUS
                    || mat == Material.POWDER_SNOW
                    || mat.isAir();
        }

        private void spawnOrbitingGear(Location center) {
            clearDisplays();
            World world = center.getWorld();
            double orbitRadius = plugin.getConfig().getDouble("briefing.orbit-radius", 2.5);
            List<String> itemNames = plugin.getConfig().getStringList("briefing.display-items");

            List<Material> materials = new ArrayList<>();
            for (String name : itemNames) {
                Material mat = Material.matchMaterial(name);
                if (mat != null && mat.isItem()) {
                    materials.add(mat);
                }
            }
            if (materials.isEmpty()) {
                materials.add(Material.TOTEM_OF_UNDYING);
            }

            int count = materials.size();
            for (int i = 0; i < count; i++) {
                double angle = (2 * Math.PI * i) / count;
                Location spawnLoc = center.clone().add(Math.cos(angle) * orbitRadius, 1.35, Math.sin(angle) * orbitRadius);

                Material itemMat = materials.get(i);
                ItemDisplay display = world.spawn(spawnLoc, ItemDisplay.class, entity -> {
                    entity.setItemStack(new ItemStack(itemMat));
                    entity.setBillboard(Display.Billboard.FIXED);
                    entity.setGlowing(true);
                    entity.setTeleportDuration(2);
                });
                activeDisplays.add(display);
            }

            new BukkitRunnable() {
                double orbitAngle = 0.0;
                float spinYaw = 0f;

                @Override
                public void run() {
                    if (activeDisplays.isEmpty()) {
                        cancel();
                        return;
                    }
                    orbitAngle += 0.09;
                    spinYaw += 0.18f;
                    int total = activeDisplays.size();

                    for (int i = 0; i < total; i++) {
                        ItemDisplay display = activeDisplays.get(i);
                        if (!display.isValid()) continue;

                        double currentAngle = orbitAngle + ((2 * Math.PI * i) / total);
                        double bobY = 1.35 + Math.sin(orbitAngle * 2.0 + i) * 0.15;
                        Location nextLoc = center.clone().add(
                                Math.cos(currentAngle) * orbitRadius,
                                bobY,
                                Math.sin(currentAngle) * orbitRadius
                        );
                        display.teleport(nextLoc);

                        display.setInterpolationDelay(0);
                        display.setInterpolationDuration(2);
                        display.setTransformation(new Transformation(
                                new Vector3f(0f, 0f, 0f),
                                new AxisAngle4f(spinYaw, 0f, 1f, 0f),
                                new Vector3f(1.25f, 1.25f, 1.25f),
                                new AxisAngle4f(0f, 0f, 1f, 0f)
                        ));
                    }
                }
            }.runTaskTimer(plugin, 0L, 2L);
        }

        private Sound parseSound(String name) {
            if (name == null || name.isBlank()) return null;
            String normalized = name.toLowerCase(Locale.ROOT).replace('_', '.');
            NamespacedKey key = NamespacedKey.fromString(normalized);
            if (key != null) {
                Sound sound = Registry.SOUNDS.get(key);
                if (sound != null) return sound;
            }
            try {
                return Sound.valueOf(name.toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                return null;
            }
        }

        private void clearDisplays() {
            activeDisplays.forEach(Display::remove);
            activeDisplays.clear();
        }

        public boolean isFrozen(UUID uuid) {
            return frozenPlayers.contains(uuid);
        }

        public boolean isRisingRelease(UUID uuid) {
            return risingReleasePlayers.contains(uuid);
        }

        public void unfreeze(Player player) {
            if (frozenPlayers.contains(player.getUniqueId())) {
                restoreNormalState(player);
            }
        }

        public void cleanup() {
            clearDisplays();
            for (UUID uuid : new HashSet<>(frozenPlayers)) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    restoreNormalState(p);
                }
            }
            frozenPlayers.clear();
            risingReleasePlayers.clear();
            activeBossBars.clear();
            previousAllowFlight.clear();
            waitingQueue.clear();
            briefingOccupied = false;
        }
    }

    // =========================================================================
    // SIMPLE VANILLA LEADERBOARD & JUMPING VICTORY PODIUM MANAGER (NO TEXTURE)
    // =========================================================================
    private static class PodiumManager {

        public record PlayerScore(UUID uuid, String name, int previousPoints, int gainedPoints) {
            public int totalPoints() {
                return previousPoints + gainedPoints;
            }
        }

        private final WynBGPlugin plugin;
        private final MiniMessage mm = MiniMessage.miniMessage();

        private final Map<UUID, Integer> totalScores = new HashMap<>();
        private final Map<UUID, Integer> lastMatchGained = new HashMap<>();
        private final Set<UUID> ceremonyLockedPlayers = new HashSet<>();
        private final Set<UUID> hoppingWinners = new HashSet<>();

        private ArmorStand activeCamera;
        private TextDisplay activeBoard;
        private boolean ceremonyRunning = false;

        public PodiumManager(WynBGPlugin plugin) {
            this.plugin = plugin;
        }

        public void addPoints(Player player, int points) {
            UUID uuid = player.getUniqueId();
            totalScores.merge(uuid, points, Integer::sum);
            lastMatchGained.merge(uuid, points, Integer::sum);
        }

        public void resetPoints() {
            totalScores.clear();
            lastMatchGained.clear();
        }

        public void startVictoryCeremony() {
            if (ceremonyRunning) return;
            ceremonyRunning = true;

            for (Player online : Bukkit.getOnlinePlayers()) {
                totalScores.putIfAbsent(online.getUniqueId(), 0);
            }

            List<PlayerScore> rankings = buildSortedRankings();
            if (rankings.isEmpty()) {
                ceremonyRunning = false;
                return;
            }

            Location camLoc = plugin.getConfigLocation("locations.podium-cam");
            Location pos1 = plugin.getConfigLocation("locations.podium-1");
            Location pos2 = plugin.getConfigLocation("locations.podium-2");
            Location pos3 = plugin.getConfigLocation("locations.podium-3");
            Location lobbyLoc = plugin.getConfigLocation("locations.lobby");

            activeCamera = camLoc.getWorld().spawn(camLoc, ArmorStand.class, stand -> {
                stand.setInvisible(true);
                stand.setGravity(false);
                stand.setMarker(true);
            });

            for (Player p : Bukkit.getOnlinePlayers()) {
                ceremonyLockedPlayers.add(p.getUniqueId());
                p.setGameMode(GameMode.SPECTATOR);
                p.setSpectatorTarget(activeCamera);
            }

            playVanillaLeaderboard(rankings, () -> {
                playJumpingPodiumSequence(rankings, camLoc, pos1, pos2, pos3, () -> {
                    lastMatchGained.clear();
                    cleanupCeremonyEntities(lobbyLoc);
                });
            });
        }

        private void playVanillaLeaderboard(List<PlayerScore> finalRankings, Runnable onComplete) {
            Vector forward = activeCamera.getLocation().getDirection().normalize();
            Location boardLoc = activeCamera.getLocation().clone().add(forward.multiply(4.2)).add(0, 1.35, 0);

            activeBoard = activeCamera.getWorld().spawn(boardLoc, TextDisplay.class, td -> {
                td.setBillboard(Display.Billboard.CENTER);
                td.setBackgroundColor(Color.fromARGB(205, 14, 16, 26));
                td.setShadowed(true);
                td.setTransformation(new Transformation(
                        new Vector3f(0f, -0.55f, 0f),
                        new AxisAngle4f(0f, 0f, 1f, 0f),
                        new Vector3f(1.35f, 1.35f, 1.35f),
                        new AxisAngle4f(0f, 0f, 1f, 0f)
                ));
            });

            new BukkitRunnable() {
                int step = 0;
                final int countUpSteps = 25;
                final int holdSteps = 20;

                @Override
                public void run() {
                    if (!ceremonyRunning || activeBoard == null) {
                        cancel();
                        return;
                    }

                    if (step > countUpSteps + holdSteps) {
                        activeBoard.remove();
                        activeBoard = null;
                        cancel();
                        onComplete.run();
                        return;
                    }

                    double ratio = Math.min(1.0, (double) step / countUpSteps);
                    List<PlayerScore> animated = new ArrayList<>();
                    for (PlayerScore ps : finalRankings) {
                        int shownGained = (int) Math.round(ps.gainedPoints() * ratio);
                        animated.add(new PlayerScore(ps.uuid(), ps.name(), ps.previousPoints(), shownGained));
                    }
                    animated.sort(Comparator.comparingInt(PlayerScore::totalPoints).reversed());

                    StringBuilder sb = new StringBuilder("<gold><bold>✦ KLASEMEN PERTANDINGAN ✦</bold>\n\n");
                    int maxRows = Math.min(8, animated.size());
                    for (int i = 0; i < maxRows; i++) {
                        PlayerScore row = animated.get(i);
                        String rankTag = switch (i) {
                            case 0 -> "<gold><bold>#1";
                            case 1 -> "<gray><bold>#2";
                            case 2 -> "<#CD7F32><bold>#3";
                            default -> "<dark_gray>#" + (i + 1);
                        };
                        sb.append(rankTag).append(" <white>").append(row.name())
                          .append("  <yellow>").append(row.totalPoints()).append(" POIN");
                        if (row.gainedPoints() > 0) {
                            sb.append(" <green>(+").append(row.gainedPoints()).append(")");
                        }
                        sb.append("\n");
                    }

                    activeBoard.text(mm.deserialize(sb.toString()));

                    if (step <= countUpSteps && step % 2 == 0) {
                        for (Player p : Bukkit.getOnlinePlayers()) {
                            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.55f, 1.45f);
                        }
                    }
                    step++;
                }
            }.runTaskTimer(plugin, 0L, 3L);
        }

        private void playJumpingPodiumSequence(List<PlayerScore> rankings, Location camLoc,
                                               Location pos1, Location pos2, Location pos3,
                                               Runnable onComplete) {
            flashScreen(Color.BLACK);

            Player first = !rankings.isEmpty() ? Bukkit.getPlayer(rankings.get(0).uuid()) : null;
            Player second = rankings.size() >= 2 ? Bukkit.getPlayer(rankings.get(1).uuid()) : null;
            Player third = rankings.size() >= 3 ? Bukkit.getPlayer(rankings.get(2).uuid()) : null;

            Vector toCamera = camLoc.toVector().subtract(pos1.toVector()).setY(0);
            if (toCamera.lengthSquared() < 0.01) {
                toCamera = new Vector(0, 0, 1);
            }
            toCamera.normalize();
            Vector rightVec = new Vector(-toCamera.getZ(), 0, toCamera.getX()).normalize();

            double baseFloorY = Math.min(pos3.getY(), Math.min(pos2.getY(), pos1.getY())) - 1.0;
            Location frontCenter = pos1.clone().add(toCamera.clone().multiply(3.2));
            frontCenter.setY(baseFloorY);
            frontCenter.setDirection(toCamera);

            prepareStageActor(first, frontCenter.clone());
            prepareStageActor(second, frontCenter.clone().add(rightVec.clone().multiply(-1.8)));
            prepareStageActor(third, frontCenter.clone().add(rightVec.clone().multiply(1.8)));

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!ceremonyRunning) return;
                if (third != null) {
                    launchAndHopOnPodium(third, pos3, 3, rankings.get(2).totalPoints(), Material.GOLD_INGOT);
                }
            }, 30L);

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!ceremonyRunning) return;
                if (second != null) {
                    launchAndHopOnPodium(second, pos2, 2, rankings.get(1).totalPoints(), Material.NETHER_STAR);
                }
            }, 100L);

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!ceremonyRunning) return;
                if (first != null) {
                    flashScreen(Color.WHITE);
                    launchAndHopOnPodium(first, pos1, 1, rankings.get(0).totalPoints(), Material.TOTEM_OF_UNDYING);
                    spawnPodiumFireworks(pos1);
                }
            }, 170L);

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (ceremonyRunning) {
                    onComplete.run();
                }
            }, 320L);
        }

        private void prepareStageActor(Player player, Location loc) {
            if (player == null || !player.isOnline()) return;
            player.setSpectatorTarget(null);
            player.setGameMode(GameMode.ADVENTURE);
            player.setAllowFlight(true);
            player.setFlying(true);
            player.teleport(loc);
        }

        private void launchAndHopOnPodium(Player winner, Location podiumTop, int rank, int points, Material vanillaTrophy) {
            String rankColor = switch (rank) {
                case 1 -> "<gold><bold>";
                case 2 -> "<aqua><bold>";
                default -> "<yellow><bold>";
            };
            String subtitleText = (rank == 1)
                    ? "<gold>★ PEMENANG UTAMA • " + points + " POIN ★"
                    : "<white>JUARA " + rank + " <gray>(" + points + " POIN)";

            Title title = Title.title(
                    mm.deserialize(rankColor + winner.getName()),
                    mm.deserialize(subtitleText),
                    Title.Times.times(Duration.ofMillis(120), Duration.ofSeconds(3), Duration.ofMillis(250))
            );

            for (Player p : Bukkit.getOnlinePlayers()) {
                p.showTitle(title);
                p.playSound(p.getLocation(),
                        rank == 1 ? Sound.UI_TOAST_CHALLENGE_COMPLETE : Sound.ENTITY_PLAYER_LEVELUP,
                        1.0f, rank == 1 ? 1.0f : 1.2f);
            }

            ItemStack trophy = new ItemStack(vanillaTrophy);
            ItemMeta meta = trophy.getItemMeta();
            if (meta != null) {
                meta.displayName(mm.deserialize(rankColor + "Piala Juara " + rank));
                trophy.setItemMeta(meta);
            }
            winner.getInventory().setItemInMainHand(trophy);
            winner.setGlowing(true);

            Location start = winner.getLocation().clone();
            new BukkitRunnable() {
                int tick = 0;
                final int jumpDuration = 16;

                @Override
                public void run() {
                    if (!ceremonyRunning || !winner.isOnline()) {
                        cancel();
                        return;
                    }

                    if (tick <= jumpDuration) {
                        double t = (double) tick / jumpDuration;
                        double x = start.getX() + (podiumTop.getX() - start.getX()) * t;
                        double z = start.getZ() + (podiumTop.getZ() - start.getZ()) * t;
                        double baseY = start.getY() + (podiumTop.getY() - start.getY()) * t;
                        double arcY = Math.sin(t * Math.PI) * 1.65;

                        Location arcLoc = new Location(podiumTop.getWorld(), x, baseY + arcY, z,
                                podiumTop.getYaw(), podiumTop.getPitch());
                        winner.teleport(arcLoc);
                        tick++;
                    } else {
                        cancel();
                        startContinuousPodiumHopping(winner, podiumTop, rank);
                    }
                }
            }.runTaskTimer(plugin, 0L, 1L);
        }

        private void startContinuousPodiumHopping(Player winner, Location podiumTop, int rank) {
            UUID uuid = winner.getUniqueId();
            hoppingWinners.add(uuid);

            new BukkitRunnable() {
                int tick = 0;

                @Override
                public void run() {
                    if (!ceremonyRunning || !hoppingWinners.contains(uuid) || !winner.isOnline()) {
                        cancel();
                        return;
                    }

                    int cycleTick = tick % 14;
                    double hopHeight = 0.0;
                    if (cycleTick < 10) {
                        double t = cycleTick / 10.0;
                        hopHeight = Math.sin(t * Math.PI) * (rank == 1 ? 0.72 : 0.55);
                    }

                    Location hopLoc = podiumTop.clone().add(0, hopHeight, 0);
                    winner.teleport(hopLoc);

                    if (cycleTick == 1) {
                        winner.swingMainHand();
                        winner.getWorld().spawnParticle(
                                rank == 1 ? Particle.FIREWORK : Particle.HAPPY_VILLAGER,
                                podiumTop.clone().add(0, 0.2, 0),
                                6, 0.3, 0.1, 0.3, 0.03
                        );
                    }

                    tick++;
                }
            }.runTaskTimer(plugin, 0L, 1L);
        }

        private void spawnPodiumFireworks(Location center) {
            World world = center.getWorld();
            new BukkitRunnable() {
                int step = 0;

                @Override
                public void run() {
                    if (!ceremonyRunning || step++ > 28) {
                        cancel();
                        return;
                    }
                    world.spawnParticle(Particle.FIREWORK, center.clone().add(0, 2.6, 0), 18, 2.2, 1.2, 2.2, 0.06);
                    world.spawnParticle(Particle.END_ROD, center.clone().add(0, 2.0, 0), 10, 1.8, 1.0, 1.8, 0.03);
                }
            }.runTaskTimer(plugin, 0L, 4L);
        }

        private void flashScreen(Color color) {
            String tag = (color == Color.WHITE) ? "<white>" : "<black>";
            Title flash = Title.title(
                    mm.deserialize(tag + "████████████████████"),
                    mm.deserialize(tag + "████████████████████"),
                    Title.Times.times(Duration.ofMillis(50), Duration.ofMillis(160), Duration.ofMillis(320))
            );
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.showTitle(flash);
            }
        }

        private List<PlayerScore> buildSortedRankings() {
            List<PlayerScore> list = new ArrayList<>();
            for (Map.Entry<UUID, Integer> entry : totalScores.entrySet()) {
                UUID uuid = entry.getKey();
                int total = entry.getValue();
                int gained = lastMatchGained.getOrDefault(uuid, 0);
                String name = Bukkit.getOfflinePlayer(uuid).getName();
                list.add(new PlayerScore(uuid, name != null ? name : "Player", total - gained, gained));
            }
            list.sort(Comparator.comparingInt(PlayerScore::totalPoints).reversed());
            return list;
        }

        public boolean isLocked(UUID uuid) {
            return ceremonyLockedPlayers.contains(uuid);
        }

        public void cleanupPlayer(Player player) {
            UUID uuid = player.getUniqueId();
            ceremonyLockedPlayers.remove(uuid);
            hoppingWinners.remove(uuid);
            player.setGlowing(false);
        }

        private void cleanupCeremonyEntities(Location lobbyLoc) {
            if (activeBoard != null) {
                activeBoard.remove();
                activeBoard = null;
            }
            if (activeCamera != null) {
                activeCamera.remove();
                activeCamera = null;
            }
            hoppingWinners.clear();
            for (UUID uuid : new HashSet<>(ceremonyLockedPlayers)) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    p.setSpectatorTarget(null);
                    p.setGlowing(false);
                    p.setFlying(false);
                    p.setAllowFlight(false);
                    p.setGameMode(GameMode.ADVENTURE);
                    p.teleport(lobbyLoc);
                }
            }
            ceremonyLockedPlayers.clear();
            ceremonyRunning = false;
        }

        public void cleanup() {
            if (activeBoard != null) {
                activeBoard.remove();
                activeBoard = null;
            }
            if (activeCamera != null) {
                activeCamera.remove();
                activeCamera = null;
            }
            hoppingWinners.clear();
            for (UUID uuid : new HashSet<>(ceremonyLockedPlayers)) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    p.setSpectatorTarget(null);
                    p.setGlowing(false);
                    p.setFlying(false);
                    p.setAllowFlight(false);
                    p.setGameMode(GameMode.ADVENTURE);
                }
            }
            ceremonyLockedPlayers.clear();
            ceremonyRunning = false;
        }
    }

    // =========================================================================
    // EVENT LISTENER
    // =========================================================================
    private static class DropListener implements Listener {

        private final WynBGPlugin plugin;
        private final BriefingManager briefingManager;
        private final ParachuteManager parachuteManager;
        private final PodiumManager podiumManager;

        public DropListener(WynBGPlugin plugin, BriefingManager briefingManager,
                            ParachuteManager parachuteManager, PodiumManager podiumManager) {
            this.plugin = plugin;
            this.briefingManager = briefingManager;
            this.parachuteManager = parachuteManager;
            this.podiumManager = podiumManager;
        }

        @EventHandler
        public void onMove(PlayerMoveEvent event) {
            Player player = event.getPlayer();
            UUID uuid = player.getUniqueId();

            if (podiumManager.isLocked(uuid)) {
                if (event.getFrom().getX() != event.getTo().getX()
                        || event.getFrom().getZ() != event.getTo().getZ()) {
                    Location locked = event.getTo().clone();
                    locked.setX(event.getFrom().getX());
                    locked.setZ(event.getFrom().getZ());
                    event.setTo(locked);
                }
                return;
            }

            if (!briefingManager.isFrozen(uuid)) return;

            if (briefingManager.isRisingRelease(uuid)) {
                if (event.getFrom().getX() != event.getTo().getX()
                        || event.getFrom().getZ() != event.getTo().getZ()) {
                    Location locked = event.getTo().clone();
                    locked.setX(event.getFrom().getX());
                    locked.setZ(event.getFrom().getZ());
                    event.setTo(locked);
                }
                return;
            }

            if (event.getFrom().getX() != event.getTo().getX()
                    || event.getFrom().getY() != event.getTo().getY()
                    || event.getFrom().getZ() != event.getTo().getZ()) {
                Location locked = event.getFrom().clone();
                locked.setYaw(event.getTo().getYaw());
                locked.setPitch(event.getTo().getPitch());
                event.setTo(locked);
            }
        }

        @EventHandler
        public void onPlayerKill(PlayerDeathEvent event) {
            Player killer = event.getEntity().getKiller();
            if (killer != null && !killer.equals(event.getEntity())) {
                int killPoints = plugin.getConfig().getInt("points.per-kill", 10);
                podiumManager.addPoints(killer, killPoints);
                killer.sendActionBar(MiniMessage.miniMessage().deserialize(
                        "<gold>+<yellow>" + killPoints + " POIN <gray>(Eliminasi " + event.getEntity().getName() + ")"
                ));
            }
        }

        @EventHandler
        public void onToggleGlide(EntityToggleGlideEvent event) {
            if (!(event.getEntity() instanceof Player player)) return;
            if (parachuteManager.isParachuting(player.getUniqueId()) && !event.isGliding() && !player.isOnGround()) {
                event.setCancelled(true);
            }
        }

        @EventHandler
        public void onArmorClick(InventoryClickEvent event) {
            if (!(event.getWhoClicked() instanceof Player player)) return;
            if (parachuteManager.isParachuting(player.getUniqueId()) && event.getSlot() == 38) {
                event.setCancelled(true);
            }
        }

        @EventHandler
        public void onDamage(EntityDamageEvent event) {
            if (!(event.getEntity() instanceof Player player)) return;
            if (briefingManager.isFrozen(player.getUniqueId()) || podiumManager.isLocked(player.getUniqueId())) {
                event.setCancelled(true);
                return;
            }
            if (parachuteManager.isParachuting(player.getUniqueId()) || parachuteManager.hasLandingGrace(player.getUniqueId())) {
                if (event.getCause() == EntityDamageEvent.DamageCause.FALL
                        || event.getCause() == EntityDamageEvent.DamageCause.FLY_INTO_WALL) {
                    event.setCancelled(true);
                }
            }
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent event) {
            Player player = event.getPlayer();
            briefingManager.unfreeze(player);
            parachuteManager.cleanupPlayer(player);
            podiumManager.cleanupPlayer(player);
        }
    }

    // =========================================================================
    // ADMIN COMMAND
    // =========================================================================
    private static class WynBGCommand implements CommandExecutor, TabCompleter {

        private final WynBGPlugin plugin;
        private final BriefingManager briefingManager;
        private final PodiumManager podiumManager;
        private final MiniMessage mm = MiniMessage.miniMessage();

        public WynBGCommand(WynBGPlugin plugin, BriefingManager briefingManager, PodiumManager podiumManager) {
            this.plugin = plugin;
            this.briefingManager = briefingManager;
            this.podiumManager = podiumManager;
        }

        @Override
        public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                                 @NotNull String label, @NotNull String[] args) {
            if (args.length == 0) {
                sender.sendMessage(mm.deserialize("<gold>WynBG <gray>» Gunakan <white>/wynbg <start|podium|addpoin|resetpoin|setqueue|setbriefing|setcenter|setpodiumcam|setpodium1|setpodium2|setpodium3|setlobby|reload>"));
                return true;
            }

            String sub = args[0].toLowerCase(Locale.ROOT);
            switch (sub) {
                case "setqueue" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.queue", player.getLocation());
                    player.sendMessage(mm.deserialize("<green>Lokasi ruang antrean (Queue) berhasil disimpan!"));
                }
                case "setbriefing" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.briefing", player.getLocation());
                    player.sendMessage(mm.deserialize("<green>Lokasi ruang briefing (Void) berhasil disimpan!"));
                }
                case "setcenter" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.arena-center", player.getLocation());
                    player.sendMessage(mm.deserialize("<green>Titik tengah arena Battleground berhasil disimpan!"));
                }
                case "setpodiumcam" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.podium-cam", player.getLocation());
                    player.sendMessage(mm.deserialize("<green>Posisi kamera Klasemen & Podium berhasil disimpan!"));
                }
                case "setpodium1" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.podium-1", player.getLocation());
                    player.sendMessage(mm.deserialize("<gold>Titik Podium Juara #1 berhasil disimpan!"));
                }
                case "setpodium2" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.podium-2", player.getLocation());
                    player.sendMessage(mm.deserialize("<aqua>Titik Podium Juara #2 berhasil disimpan!"));
                }
                case "setpodium3" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.podium-3", player.getLocation());
                    player.sendMessage(mm.deserialize("<yellow>Titik Podium Juara #3 berhasil disimpan!"));
                }
                case "setlobby" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.lobby", player.getLocation());
                    player.sendMessage(mm.deserialize("<green>Titik kembali ke Lobby berhasil disimpan!"));
                }
                case "start" -> {
                    DropMode mode = DropMode.SOLO;
                    if (args.length >= 2 && args[1].equalsIgnoreCase("squad")) {
                        mode = DropMode.SQUAD;
                    }
                    List<Player> targets = new ArrayList<>(Bukkit.getOnlinePlayers());
                    briefingManager.enqueueDeployment(targets, mode);
                    sender.sendMessage(mm.deserialize("<gold>Memulai sekuens terjun mode <yellow>" + mode.name()
                            + " <gold>untuk <white>" + targets.size() + " <gold>pemain."));
                }
                case "podium" -> {
                    podiumManager.startVictoryCeremony();
                    sender.sendMessage(mm.deserialize("<gold>Memulai animasi Klasemen & Podium Kemenangan!"));
                }
                case "addpoin" -> {
                    if (args.length < 3) {
                        sender.sendMessage(mm.deserialize("<red>Gunakan: /wynbg addpoin <nama_player> <jumlah>"));
                        return true;
                    }
                    Player target = Bukkit.getPlayer(args[1]);
                    if (target == null) {
                        sender.sendMessage(mm.deserialize("<red>Player tidak ditemukan atau sedang offline."));
                        return true;
                    }
                    try {
                        int pts = Integer.parseInt(args[2]);
                        podiumManager.addPoints(target, pts);
                        sender.sendMessage(mm.deserialize("<green>Menambahkan <yellow>" + pts + " poin <green>ke <white>" + target.getName()));
                    } catch (NumberFormatException e) {
                        sender.sendMessage(mm.deserialize("<red>Jumlah poin harus berupa angka."));
                    }
                }
                case "resetpoin" -> {
                    podiumManager.resetPoints();
                    sender.sendMessage(mm.deserialize("<yellow>Seluruh poin klasemen berhasil direset."));
                }
                case "reload" -> {
                    plugin.reloadConfig();
                    sender.sendMessage(mm.deserialize("<green>Konfigurasi config.yml berhasil dimuat ulang!"));
                }
                default -> sender.sendMessage(mm.deserialize("<red>Sub-command tidak dikenal."));
            }
            return true;
        }

        @Override
        public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                          @NotNull String alias, @NotNull String[] args) {
            if (args.length == 1) {
                return List.of("start", "podium", "addpoin", "resetpoin",
                        "setqueue", "setbriefing", "setcenter",
                        "setpodiumcam", "setpodium1", "setpodium2", "setpodium3", "setlobby", "reload");
            }
            if (args.length == 2 && args[0].equalsIgnoreCase("start")) {
                return List.of("solo", "squad");
            }
            if (args.length == 2 && args[0].equalsIgnoreCase("addpoin")) {
                return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
            }
            return List.of();
        }
    }
}
