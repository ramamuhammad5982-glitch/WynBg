package id.wynbg;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.WeatherType;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Transformation;
import org.jetbrains.annotations.NotNull;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;

public class WynBGPlugin extends JavaPlugin {

    public enum DropMode {
        SOLO,
        SQUAD
    }

    private ParachuteManager parachuteManager;
    private BriefingManager briefingManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.parachuteManager = new ParachuteManager(this);
        this.briefingManager = new BriefingManager(this, parachuteManager);

        getServer().getPluginManager().registerEvents(
                new DropListener(briefingManager, parachuteManager), this
        );

        WynBGCommand cmd = new WynBGCommand(this, briefingManager);
        if (getCommand("wynbg") != null) {
            getCommand("wynbg").setExecutor(cmd);
            getCommand("wynbg").setTabCompleter(cmd);
        }

        getLogger().info("WynBG (Cinematic Void & Solo/Squad Parachute Drop) aktif di Paper 1.21.1!");
    }

    @Override
    public void onDisable() {
        if (briefingManager != null) {
            briefingManager.cleanup();
        }
        if (parachuteManager != null) {
            parachuteManager.cleanupAll();
        }
    }

    public Location getConfigLocation(String path) {
        String worldName = getConfig().getString(path + ".world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            world = Bukkit.getWorlds().getFirst();
        }
        double x = getConfig().getDouble(path + ".x", 0.5);
        double y = getConfig().getDouble(path + ".y", 100.0);
        double z = getConfig().getDouble(path + ".z", 0.5);
        float yaw = (float) getConfig().getDouble(path + ".yaw", 0.0);
        float pitch = (float) getConfig().getDouble(path + ".pitch", 0.0);
        return new Location(world, x, y, z, yaw, pitch);
    }

    public void saveConfigLocation(String path, Location loc) {
        getConfig().set(path + ".world", loc.getWorld().getName());
        getConfig().set(path + ".x", loc.getX());
        getConfig().set(path + ".y", loc.getY());
        getConfig().set(path + ".z", loc.getZ());
        getConfig().set(path + ".yaw", loc.getYaw());
        getConfig().set(path + ".pitch", loc.getPitch());
        saveConfig();
    }

    // =========================================================================
    // PARACHUTE & LANDING VFX MANAGER
    // =========================================================================
    private static class ParachuteManager {

        private final WynBGPlugin plugin;
        private final MiniMessage mm = MiniMessage.miniMessage();
        private final Set<UUID> parachutingPlayers = new HashSet<>();
        private final Set<UUID> landingGracePlayers = new HashSet<>();
        private final Map<UUID, ItemStack> savedChestplates = new HashMap<>();

        public ParachuteManager(WynBGPlugin plugin) {
            this.plugin = plugin;
            startParachuteAndLandingWatcher();
        }

        public void deployWithParachute(Player player, Location dropLocation) {
            UUID uuid = player.getUniqueId();
            player.teleport(dropLocation);
            player.setFallDistance(0f);

            ItemStack currentChest = player.getInventory().getChestplate();
            if (currentChest != null && currentChest.getType() != Material.AIR) {
                savedChestplates.put(uuid, currentChest.clone());
            }

            ItemStack parachute = new ItemStack(Material.ELYTRA);
            ItemMeta meta = parachute.getItemMeta();
            if (meta != null) {
                meta.displayName(mm.deserialize("<aqua><bold>Parasut Taktis"));
                meta.setUnbreakable(true);
                parachute.setItemMeta(meta);
            }

            player.getInventory().setChestplate(parachute);
            player.setGliding(true);
            parachutingPlayers.add(uuid);

            // Flash putih terang saat keluar dari dimensi void ke langit arena
            Title whiteFlash = Title.title(
                    mm.deserialize("<white>████████████████████"),
                    mm.deserialize("<white>████████████████████"),
                    Title.Times.times(Duration.ofMillis(80), Duration.ofMillis(220), Duration.ofMillis(450))
            );
            player.showTitle(whiteFlash);

            player.playSound(dropLocation, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.0f, 1.1f);
            player.playSound(dropLocation, Sound.ITEM_ELYTRA_FLYING, 1.0f, 1.0f);
            player.sendActionBar(mm.deserialize("<aqua>Parasut terbuka! Arahkan pandangan untuk mendarat."));
        }

        private void startParachuteAndLandingWatcher() {
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (parachutingPlayers.isEmpty()) return;

                    Iterator<UUID> iterator = parachutingPlayers.iterator();
                    while (iterator.hasNext()) {
                        UUID uuid = iterator.next();
                        Player player = Bukkit.getPlayer(uuid);
                        if (player == null || !player.isOnline()) {
                            iterator.remove();
                            savedChestplates.remove(uuid);
                            continue;
                        }

                        // Jejak partikel bintang putih saat meluncur di udara (seperti di video)
                        Location trailLoc = player.getLocation().add(0, 0.8, 0);
                        player.getWorld().spawnParticle(Particle.FIREWORK, trailLoc, 3, 0.25, 0.25, 0.25, 0.02);
                        player.getWorld().spawnParticle(Particle.END_ROD, trailLoc, 2, 0.2, 0.2, 0.2, 0.01);

                        if (player.isOnGround() || player.isInWater()) {
                            iterator.remove();
                            completeLanding(player);
                        }
                    }
                }
            }.runTaskTimer(plugin, 2L, 2L);
        }

        private void completeLanding(Player player) {
            UUID uuid = player.getUniqueId();
            player.setGliding(false);
            player.setFallDistance(0f);

            ItemStack previousChest = savedChestplates.remove(uuid);
            player.getInventory().setChestplate(previousChest);

            landingGracePlayers.add(uuid);
            Bukkit.getScheduler().runTaskLater(plugin, () -> landingGracePlayers.remove(uuid), 60L);

            player.playSound(player.getLocation(), Sound.ITEM_ARMOR_EQUIP_LEATHER, 1.0f, 1.1f);
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.9f, 1.3f);
            player.sendActionBar(mm.deserialize("<green><bold>MENDARAT! <gray>Segera cari perlengkapan."));

            spawnLandingShockwaveRing(player.getLocation());
        }

        private void spawnLandingShockwaveRing(Location center) {
            World world = center.getWorld();
            Particle.DustOptions whiteDust = new Particle.DustOptions(Color.WHITE, 1.2f);
            Particle.DustOptions limeDust = new Particle.DustOptions(Color.fromRGB(110, 255, 110), 1.1f);

            new BukkitRunnable() {
                int step = 0;

                @Override
                public void run() {
                    if (step > 10) {
                        cancel();
                        return;
                    }

                    double radius = 0.6 + (step * 0.22);
                    int points = 24;
                    for (int i = 0; i < points; i++) {
                        double angle = (2 * Math.PI * i) / points;
                        double x = Math.cos(angle) * radius;
                        double z = Math.sin(angle) * radius;
                        Location ringLoc = center.clone().add(x, 0.15, z);

                        world.spawnParticle(Particle.DUST, ringLoc, 1, 0, 0, 0, 0, whiteDust);
                        if (i % 3 == 0) {
                            world.spawnParticle(Particle.DUST, ringLoc.clone().add(0, 0.1, 0), 1, 0, 0, 0, 0, limeDust);
                        }
                    }

                    if (step % 2 == 0) {
                        world.spawnParticle(Particle.FIREWORK, center.clone().add(0, 1.0, 0), 6, 0.6, 0.8, 0.6, 0.03);
                    }

                    step++;
                }
            }.runTaskTimer(plugin, 0L, 2L);
        }

        public boolean isParachuting(UUID uuid) {
            return parachutingPlayers.contains(uuid);
        }

        public boolean hasLandingGrace(UUID uuid) {
            return landingGracePlayers.contains(uuid);
        }

        public void cleanupPlayer(Player player) {
            UUID uuid = player.getUniqueId();
            if (parachutingPlayers.remove(uuid)) {
                player.getInventory().setChestplate(savedChestplates.remove(uuid));
            }
            landingGracePlayers.remove(uuid);
        }

        public void cleanupAll() {
            for (UUID uuid : new HashSet<>(parachutingPlayers)) {
                Player player = Bukkit.getPlayer(uuid);
                if (player != null) {
                    cleanupPlayer(player);
                }
            }
            parachutingPlayers.clear();
            savedChestplates.clear();
            landingGracePlayers.clear();
        }
    }

    // =========================================================================
    // VOID BRIEFING & CINEMATIC DEPLOYMENT MANAGER
    // =========================================================================
    private static class BriefingManager {

        private record QueuedBatch(List<UUID> playerIds, DropMode mode) {}

        private final WynBGPlugin plugin;
        private final ParachuteManager parachuteManager;
        private final MiniMessage mm = MiniMessage.miniMessage();

        private final Queue<QueuedBatch> waitingQueue = new LinkedList<>();
        private final Set<UUID> frozenPlayers = new HashSet<>();
        private final Set<UUID> risingReleasePlayers = new HashSet<>();
        private final Map<UUID, Boolean> previousAllowFlight = new HashMap<>();
        private final Map<UUID, BossBar> activeBossBars = new HashMap<>();
        private final List<ItemDisplay> activeDisplays = new ArrayList<>();
        private boolean briefingOccupied = false;

        public BriefingManager(WynBGPlugin plugin, ParachuteManager parachuteManager) {
            this.plugin = plugin;
            this.parachuteManager = parachuteManager;
            startQueueNotifier();
        }

        public void enqueueDeployment(List<Player> players, DropMode mode) {
            List<UUID> ids = players.stream().map(Player::getUniqueId).toList();
            if (ids.isEmpty()) return;

            if (briefingOccupied) {
                Location queueLoc = plugin.getConfigLocation("locations.queue");
                for (Player p : players) {
                    prepareVoidStasis(p, queueLoc, 20 * 60);
                }
                waitingQueue.add(new QueuedBatch(ids, mode));
            } else {
                runBriefingSession(ids, mode);
            }
        }

        private void prepareVoidStasis(Player player, Location loc, int durationTicks) {
            UUID uuid = player.getUniqueId();
            frozenPlayers.add(uuid);
            risingReleasePlayers.remove(uuid);

            previousAllowFlight.putIfAbsent(uuid, player.getAllowFlight());
            player.setAllowFlight(true);
            player.setFlying(true);
            player.setFallDistance(0f);
            player.teleport(loc);

            // Efek void gelap: Blindness + Darkness + langit malam 18000 agar area sekitar tidak terlihat
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.BLINDNESS, durationTicks, 1, false, false, false
            ));
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.DARKNESS, durationTicks, 0, false, false, false
            ));
            player.setPlayerTime(18000L, false);
            player.setPlayerWeather(WeatherType.CLEAR);
        }

        private void restoreNormalState(Player player) {
            UUID uuid = player.getUniqueId();
            frozenPlayers.remove(uuid);
            risingReleasePlayers.remove(uuid);

            BossBar bar = activeBossBars.remove(uuid);
            if (bar != null) {
                player.hideBossBar(bar);
            }

            player.removePotionEffect(PotionEffectType.BLINDNESS);
            player.removePotionEffect(PotionEffectType.DARKNESS);
            player.resetPlayerTime();
            player.resetPlayerWeather();

            Boolean wasAllowed = previousAllowFlight.remove(uuid);
            boolean allowFlight = wasAllowed != null && wasAllowed;
            player.setFlying(false);
            player.setAllowFlight(allowFlight);
        }

        private void startQueueNotifier() {
            new BukkitRunnable() {
                int dotStep = 0;

                @Override
                public void run() {
                    if (waitingQueue.isEmpty()) return;
                    dotStep = (dotStep % 3) + 1;
                    String dots = ".".repeat(dotStep);

                    int position = 1;
                    for (QueuedBatch batch : waitingQueue) {
                        Title title = Title.title(
                                mm.deserialize("<yellow><bold>MENUNGGU GILIRAN" + dots),
                                mm.deserialize("<gray>Antrean ke-<white>" + position + " <gray>| Ruang briefing sedang dipakai"),
                                Title.Times.times(Duration.ZERO, Duration.ofMillis(1200), Duration.ZERO)
                        );
                        for (UUID uuid : batch.playerIds()) {
                            Player p = Bukkit.getPlayer(uuid);
                            if (p != null && p.isOnline()) {
                                p.showTitle(title);
                            }
                        }
                        position++;
                    }
                }
            }.runTaskTimer(plugin, 20L, 20L);
        }

        private void runBriefingSession(List<UUID> playerIds, DropMode mode) {
            briefingOccupied = true;
            Location briefingLoc = plugin.getConfigLocation("locations.briefing");
            int deployAtSeconds = Math.max(4, plugin.getConfig().getInt("briefing.deploy-at-seconds", 9));
            int releasePhaseSeconds = Math.min(3, deployAtSeconds - 1);
            int voidTicks = (deployAtSeconds + 2) * 20;

            List<Player> participants = new ArrayList<>();
            for (UUID uuid : playerIds) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    participants.add(p);
                    prepareVoidStasis(p, briefingLoc, voidTicks);

                    BossBar bar = BossBar.bossBar(
                            mm.deserialize("<light_purple>✦ <white>Bersiap Terjun dalam <yellow>00:" + String.format("%02d", deployAtSeconds) + " <light_purple>✦"),
                            1.0f,
                            BossBar.Color.PURPLE,
                            BossBar.Overlay.PROGRESS
                    );
                    p.showBossBar(bar);
                    activeBossBars.put(uuid, bar);
                }
            }

            if (participants.isEmpty()) {
                finishBriefingAndAdvanceQueue();
                return;
            }

            spawnOrbitingGear(briefingLoc);
            startVoidAndNebulaParticles(participants, deployAtSeconds, releasePhaseSeconds);

            ConfigurationSection slidesSec = plugin.getConfig().getConfigurationSection("briefing.slides");

            new BukkitRunnable() {
                int elapsedSeconds = 0;

                @Override
                public void run() {
                    int remaining = Math.max(0, deployAtSeconds - elapsedSeconds);
                    float progress = Math.max(0.0f, Math.min(1.0f, (float) remaining / deployAtSeconds));
                    boolean inReleasePhase = remaining <= releasePhaseSeconds && remaining > 0;

                    for (Player p : participants) {
                        if (!p.isOnline()) continue;
                        BossBar bar = activeBossBars.get(p.getUniqueId());
                        if (bar != null) {
                            bar.progress(progress);
                            if (inReleasePhase) {
                                bar.name(mm.deserialize("<light_purple>✦ <white>Langit Terbuka — Meluncur! <light_purple>✦"));
                            } else {
                                bar.name(mm.deserialize("<light_purple>✦ <white>Bersiap Terjun dalam <yellow>00:"
                                        + String.format("%02d", remaining) + " <light_purple>✦"));
                            }
                        }
                    }

                    if (slidesSec != null) {
                        for (String key : slidesSec.getKeys(false)) {
                            int delay = slidesSec.getInt(key + ".delay-seconds", -1);
                            if (delay == elapsedSeconds) {
                                String rawTitle = slidesSec.getString(key + ".title", "");
                                String rawSub = slidesSec.getString(key + ".subtitle", "")
                                        .replace("{mode}", mode.name());
                                String soundName = slidesSec.getString(key + ".sound", "BLOCK_NOTE_BLOCK_PLING");
                                float pitch = (float) slidesSec.getDouble(key + ".pitch", 1.0);

                                Title title = Title.title(
                                        mm.deserialize(rawTitle),
                                        mm.deserialize(rawSub),
                                        Title.Times.times(Duration.ofMillis(150), Duration.ofSeconds(2), Duration.ofMillis(150))
                                );

                                Sound sound = parseSound(soundName);
                                for (Player p : participants) {
                                    if (!p.isOnline()) continue;
                                    p.showTitle(title);
                                    if (sound != null) {
                                        p.playSound(p.getLocation(), sound, 1.0f, pitch);
                                    }
                                }
                            }
                        }
                    }

                    if (elapsedSeconds >= deployAtSeconds) {
                        clearDisplays();
                        for (Player p : participants) {
                            if (p.isOnline()) {
                                restoreNormalState(p);
                            }
                        }
                        executeDeployment(participants, mode);
                        finishBriefingAndAdvanceQueue();
                        cancel();
                        return;
                    }

                    elapsedSeconds++;
                }
            }.runTaskTimer(plugin, 0L, 20L);
        }

        private void startVoidAndNebulaParticles(List<Player> participants, int deployAtSeconds, int releasePhaseSeconds) {
            int totalTicks = deployAtSeconds * 20;
            int spiralTicks = Math.max(20, (deployAtSeconds - releasePhaseSeconds) * 20);

            Particle.DustOptions whiteTrailDust = new Particle.DustOptions(Color.WHITE, 1.3f);
            Particle.DustOptions purpleDust = new Particle.DustOptions(Color.fromRGB(165, 75, 255), 1.1f);
            Particle.DustOptions nebulaBlueDust = new Particle.DustOptions(Color.fromRGB(35, 75, 210), 1.6f);
            Particle.DustOptions nebulaVioletDust = new Particle.DustOptions(Color.fromRGB(130, 50, 220), 1.4f);

            new BukkitRunnable() {
                int ticks = 0;
                double angle = 0.0;

                @Override
                public void run() {
                    if (ticks >= totalTicks || !briefingOccupied) {
                        cancel();
                        return;
                    }

                    if (ticks < spiralTicks) {
                        // FASE 1 (seperti 00:04 - 00:07 di video): Ekor partikel putih padat berputar naik mengelilingi badan player
                        double progress = (double) ticks / spiralTicks;
                        double headHeight = 0.1 + (progress * 2.1);

                        for (Player p : participants) {
                            if (!p.isOnline() || !frozenPlayers.contains(p.getUniqueId())) continue;
                            Location base = p.getLocation();
                            World world = base.getWorld();

                            // Gambar ekor komet putih sepanjang 12 titik yang melingkar naik ke atas
                            for (int tail = 0; tail < 12; tail++) {
                                double backFraction = tail * 0.045;
                                double yOffset = Math.max(0.05, headHeight - backFraction);
                                double theta = angle - (tail * 0.28);
                                double radius = 0.68;

                                Location pLoc = base.clone().add(
                                        Math.cos(theta) * radius,
                                        yOffset,
                                        Math.sin(theta) * radius
                                );
                                world.spawnParticle(Particle.DUST, pLoc, 1, 0, 0, 0, 0, whiteTrailDust);
                                if (tail == 0) {
                                    world.spawnParticle(Particle.END_ROD, pLoc, 2, 0.03, 0.03, 0.03, 0.005);
                                } else if (tail % 4 == 0) {
                                    world.spawnParticle(Particle.DUST, pLoc, 1, 0.04, 0.04, 0.04, 0, purpleDust);
                                }
                            }
                        }
                    } else {
                        // FASE 2 (seperti 00:12 - 00:20 di video): Pusaran Nebula biru-ungu + kilau putih & pemain mulai terangkat ke atas
                        double releaseProgress = (double) (ticks - spiralTicks) / Math.max(1, totalTicks - spiralTicks);
                        double vortexRadius = 1.2 + (releaseProgress * 2.2);

                        for (Player p : participants) {
                            if (!p.isOnline() || !frozenPlayers.contains(p.getUniqueId())) continue;
                            risingReleasePlayers.add(p.getUniqueId());

                            // Angkat pemain perlahan ke atas menuju langit terjun
                            Location risen = p.getLocation().add(0, 0.14, 0);
                            p.teleport(risen);

                            World world = risen.getWorld();
                            int arms = 3;
                            for (int arm = 0; arm < arms; arm++) {
                                double armBaseAngle = angle + ((2 * Math.PI * arm) / arms);
                                for (int step = 1; step <= 6; step++) {
                                    double r = (vortexRadius / 6.0) * step;
                                    double theta = armBaseAngle + (step * 0.35);
                                    double yWave = Math.sin(theta * 2.0) * 0.25 + 0.8;

                                    Location vortexLoc = risen.clone().add(
                                            Math.cos(theta) * r,
                                            yWave,
                                            Math.sin(theta) * r
                                    );
                                    world.spawnParticle(Particle.DUST, vortexLoc, 1, 0.08, 0.08, 0.08, 0, nebulaBlueDust);
                                    if (step % 2 == 0) {
                                        world.spawnParticle(Particle.DUST, vortexLoc.clone().add(0, -0.3, 0), 1, 0.1, 0.1, 0.1, 0, nebulaVioletDust);
                                    }
                                    if (step == 6) {
                                        world.spawnParticle(Particle.FIREWORK, vortexLoc, 1, 0.05, 0.05, 0.05, 0.01);
                                    }
                                }
                            }
                        }
                    }

                    angle += 0.45;
                    ticks += 2;
                }
            }.runTaskTimer(plugin, 0L, 2L);
        }

        private void finishBriefingAndAdvanceQueue() {
            briefingOccupied = false;
            QueuedBatch next = waitingQueue.poll();
            if (next != null) {
                runBriefingSession(next.playerIds(), next.mode());
            }
        }

        private void executeDeployment(List<Player> players, DropMode mode) {
            Location center = plugin.getConfigLocation("locations.arena-center");
            World arenaWorld = center.getWorld();
            int spreadRadius = plugin.getConfig().getInt("deployment.spread-radius", 250);
            int minDistance = plugin.getConfig().getInt("deployment.min-spread-distance", 35);
            int heightOffset = plugin.getConfig().getInt("deployment.drop-height-offset", 120);

            List<int[]> usedAnchorCoords = new ArrayList<>();

            if (mode == DropMode.SOLO) {
                for (Player player : players) {
                    if (!player.isOnline()) continue;
                    findSafeCoordAsync(arenaWorld, center.getBlockX(), center.getBlockZ(), spreadRadius, minDistance, usedAnchorCoords, 0, safeLoc -> {
                        Location dropLoc = safeLoc.clone().add(0.5, heightOffset, 0.5);
                        parachuteManager.deployWithParachute(player, dropLoc);
                    });
                }
            } else {
                List<List<Player>> squads = buildSquads(players);
                double formationRadius = plugin.getConfig().getDouble("deployment.squad-formation-radius", 4.5);

                for (List<Player> squad : squads) {
                    findSafeCoordAsync(arenaWorld, center.getBlockX(), center.getBlockZ(), spreadRadius, minDistance, usedAnchorCoords, 0, anchorLoc -> {
                        int count = squad.size();
                        for (int i = 0; i < count; i++) {
                            Player member = squad.get(i);
                            if (!member.isOnline()) continue;

                            double angle = (2 * Math.PI * i) / Math.max(1, count);
                            double offsetX = (count == 1) ? 0.5 : Math.cos(angle) * formationRadius;
                            double offsetZ = (count == 1) ? 0.5 : Math.sin(angle) * formationRadius;

                            Location memberDropLoc = anchorLoc.clone().add(offsetX, heightOffset, offsetZ);
                            parachuteManager.deployWithParachute(member, memberDropLoc);
                        }
                    });
                }
            }
        }

        private List<List<Player>> buildSquads(List<Player> players) {
            int maxSquadSize = Math.max(1, plugin.getConfig().getInt("deployment.squad-size", 4));
            Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();

            Map<String, List<Player>> teamGroups = new LinkedHashMap<>();
            List<Player> unassigned = new ArrayList<>();

            for (Player p : players) {
                if (!p.isOnline()) continue;
                Team team = scoreboard.getEntryTeam(p.getName());
                if (team != null) {
                    teamGroups.computeIfAbsent(team.getName(), k -> new ArrayList<>()).add(p);
                } else {
                    unassigned.add(p);
                }
            }

            List<List<Player>> result = new ArrayList<>(teamGroups.values());
            Collections.shuffle(unassigned);

            for (int i = 0; i < unassigned.size(); i += maxSquadSize) {
                result.add(unassigned.subList(i, Math.min(i + maxSquadSize, unassigned.size())));
            }
            return result;
        }

        private void findSafeCoordAsync(World world, int centerX, int centerZ, int radius, int minDistance,
                                        List<int[]> usedCoords, int attemptCount, Consumer<Location> callback) {
            int x = centerX + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
            int z = centerZ + ThreadLocalRandom.current().nextInt(-radius, radius + 1);

            for (int attempt = 0; attempt < 15; attempt++) {
                boolean tooClose = false;
                for (int[] existing : usedCoords) {
                    double distSq = Math.pow(existing[0] - x, 2) + Math.pow(existing[1] - z, 2);
                    if (distSq < (double) minDistance * minDistance) {
                        tooClose = true;
                        break;
                    }
                }
                if (!tooClose) break;
                x = centerX + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
                z = centerZ + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
            }

            final int finalX = x;
            final int finalZ = z;

            world.getChunkAtAsync(finalX >> 4, finalZ >> 4).thenAccept(chunk -> {
                int highestY = world.getHighestBlockYAt(finalX, finalZ);
                Material surface = world.getBlockAt(finalX, highestY, finalZ).getType();
                Location candidate = new Location(world, finalX, highestY + 1.0, finalZ);

                if (attemptCount < 15 && (isUnsafeSurface(surface) || !world.getWorldBorder().isInside(candidate))) {
                    findSafeCoordAsync(world, centerX, centerZ, radius, minDistance, usedCoords, attemptCount + 1, callback);
                    return;
                }

                usedCoords.add(new int[]{finalX, finalZ});
                callback.accept(candidate);
            });
        }

        private boolean isUnsafeSurface(Material mat) {
            return mat == Material.WATER
                    || mat == Material.LAVA
                    || mat == Material.MAGMA_BLOCK
                    || mat == Material.FIRE
                    || mat == Material.CAMPFIRE
                    || mat == Material.CACTUS
                    || mat == Material.POWDER_SNOW
                    || mat.isAir();
        }

        private void spawnOrbitingGear(Location center) {
            clearDisplays();
            World world = center.getWorld();
            double orbitRadius = plugin.getConfig().getDouble("briefing.orbit-radius", 2.5);
            List<String> itemNames = plugin.getConfig().getStringList("briefing.display-items");

            List<Material> materials = new ArrayList<>();
            for (String name : itemNames) {
                Material mat = Material.matchMaterial(name);
                if (mat != null && mat.isItem()) {
                    materials.add(mat);
                }
            }
            if (materials.isEmpty()) {
                materials.add(Material.TOTEM_OF_UNDYING);
            }

            int count = materials.size();
            for (int i = 0; i < count; i++) {
                double angle = (2 * Math.PI * i) / count;
                Location spawnLoc = center.clone().add(Math.cos(angle) * orbitRadius, 1.35, Math.sin(angle) * orbitRadius);

                Material itemMat = materials.get(i);
                ItemDisplay display = world.spawn(spawnLoc, ItemDisplay.class, entity -> {
                    entity.setItemStack(new ItemStack(itemMat));
                    entity.setBillboard(Display.Billboard.FIXED);
                    entity.setGlowing(true);
                    entity.setTeleportDuration(2);
                });
                activeDisplays.add(display);
            }

            new BukkitRunnable() {
                double orbitAngle = 0.0;
                float spinYaw = 0f;

                @Override
                public void run() {
                    if (activeDisplays.isEmpty()) {
                        cancel();
                        return;
                    }
                    orbitAngle += 0.09;
                    spinYaw += 0.18f;
                    int total = activeDisplays.size();

                    for (int i = 0; i < total; i++) {
                        ItemDisplay display = activeDisplays.get(i);
                        if (!display.isValid()) continue;

                        double currentAngle = orbitAngle + ((2 * Math.PI * i) / total);
                        double bobY = 1.35 + Math.sin(orbitAngle * 2.0 + i) * 0.15;
                        Location nextLoc = center.clone().add(
                                Math.cos(currentAngle) * orbitRadius,
                                bobY,
                                Math.sin(currentAngle) * orbitRadius
                        );
                        display.teleport(nextLoc);

                        display.setInterpolationDelay(0);
                        display.setInterpolationDuration(2);
                        display.setTransformation(new Transformation(
                                new Vector3f(0f, 0f, 0f),
                                new AxisAngle4f(spinYaw, 0f, 1f, 0f),
                                new Vector3f(1.25f, 1.25f, 1.25f),
                                new AxisAngle4f(0f, 0f, 1f, 0f)
                        ));
                    }
                }
            }.runTaskTimer(plugin, 0L, 2L);
        }

        private Sound parseSound(String name) {
            if (name == null || name.isBlank()) return null;
            String normalized = name.toLowerCase(Locale.ROOT).replace('_', '.');
            NamespacedKey key = NamespacedKey.fromString(normalized);
            if (key != null) {
                Sound sound = Registry.SOUNDS.get(key);
                if (sound != null) return sound;
            }
            try {
                return Sound.valueOf(name.toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                return null;
            }
        }

        private void clearDisplays() {
            activeDisplays.forEach(Display::remove);
            activeDisplays.clear();
        }

        public boolean isFrozen(UUID uuid) {
            return frozenPlayers.contains(uuid);
        }

        public boolean isRisingRelease(UUID uuid) {
            return risingReleasePlayers.contains(uuid);
        }

        public void unfreeze(Player player) {
            if (frozenPlayers.contains(player.getUniqueId())) {
                restoreNormalState(player);
            }
        }

        public void cleanup() {
            clearDisplays();
            for (UUID uuid : new HashSet<>(frozenPlayers)) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    restoreNormalState(p);
                }
            }
            frozenPlayers.clear();
            risingReleasePlayers.clear();
            activeBossBars.clear();
            previousAllowFlight.clear();
            waitingQueue.clear();
            briefingOccupied = false;
        }
    }

    // =========================================================================
    // EVENT LISTENER
    // =========================================================================
    private static class DropListener implements Listener {

        private final BriefingManager briefingManager;
        private final ParachuteManager parachuteManager;

        public DropListener(BriefingManager briefingManager, ParachuteManager parachuteManager) {
            this.briefingManager = briefingManager;
            this.parachuteManager = parachuteManager;
        }

        @EventHandler
        public void onMove(PlayerMoveEvent event) {
            Player player = event.getPlayer();
            UUID uuid = player.getUniqueId();
            if (!briefingManager.isFrozen(uuid)) return;

            // Izinkan gerakan naik vertikal otomatis saat fase pelepasan nebula, kunci gerakan horizontal
            if (briefingManager.isRisingRelease(uuid)) {
                if (event.getFrom().getX() != event.getTo().getX()
                        || event.getFrom().getZ() != event.getTo().getZ()) {
                    Location locked = event.getTo().clone();
                    locked.setX(event.getFrom().getX());
                    locked.setZ(event.getFrom().getZ());
                    event.setTo(locked);
                }
                return;
            }

            if (event.getFrom().getX() != event.getTo().getX()
                    || event.getFrom().getY() != event.getTo().getY()
                    || event.getFrom().getZ() != event.getTo().getZ()) {
                Location locked = event.getFrom().clone();
                locked.setYaw(event.getTo().getYaw());
                locked.setPitch(event.getTo().getPitch());
                event.setTo(locked);
            }
        }

        @EventHandler
        public void onToggleGlide(EntityToggleGlideEvent event) {
            if (!(event.getEntity() instanceof Player player)) return;
            if (parachuteManager.isParachuting(player.getUniqueId()) && !event.isGliding() && !player.isOnGround()) {
                event.setCancelled(true);
            }
        }

        @EventHandler
        public void onArmorClick(InventoryClickEvent event) {
            if (!(event.getWhoClicked() instanceof Player player)) return;
            if (parachuteManager.isParachuting(player.getUniqueId()) && event.getSlot() == 38) {
                event.setCancelled(true);
            }
        }

        @EventHandler
        public void onDamage(EntityDamageEvent event) {
            if (!(event.getEntity() instanceof Player player)) return;
            if (briefingManager.isFrozen(player.getUniqueId())) {
                event.setCancelled(true);
                return;
            }
            if (parachuteManager.isParachuting(player.getUniqueId()) || parachuteManager.hasLandingGrace(player.getUniqueId())) {
                if (event.getCause() == EntityDamageEvent.DamageCause.FALL
                        || event.getCause() == EntityDamageEvent.DamageCause.FLY_INTO_WALL) {
                    event.setCancelled(true);
                }
            }
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent event) {
            Player player = event.getPlayer();
            briefingManager.unfreeze(player);
            parachuteManager.cleanupPlayer(player);
        }
    }

    // =========================================================================
    // ADMIN COMMAND
    // =========================================================================
    private static class WynBGCommand implements CommandExecutor, TabCompleter {

        private final WynBGPlugin plugin;
        private final BriefingManager briefingManager;
        private final MiniMessage mm = MiniMessage.miniMessage();

        public WynBGCommand(WynBGPlugin plugin, BriefingManager briefingManager) {
            this.plugin = plugin;
            this.briefingManager = briefingManager;
        }

        @Override
        public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                                 @NotNull String label, @NotNull String[] args) {
            if (args.length == 0) {
                sender.sendMessage(mm.deserialize("<gold>WynBG <gray>» Gunakan <white>/wynbg <start|setqueue|setbriefing|setcenter|reload>"));
                return true;
            }

            String sub = args[0].toLowerCase(Locale.ROOT);
            switch (sub) {
                case "setqueue" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.queue", player.getLocation());
                    player.sendMessage(mm.deserialize("<green>Lokasi ruang antrean (Queue) berhasil disimpan!"));
                }
                case "setbriefing" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.briefing", player.getLocation());
                    player.sendMessage(mm.deserialize("<green>Lokasi ruang briefing (animasi item) berhasil disimpan!"));
                }
                case "setcenter" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.arena-center", player.getLocation());
                    player.sendMessage(mm.deserialize("<green>Titik tengah arena Battleground berhasil disimpan!"));
                }
                case "start" -> {
                    DropMode mode = DropMode.SOLO;
                    if (args.length >= 2 && args[1].equalsIgnoreCase("squad")) {
                        mode = DropMode.SQUAD;
                    }
                    List<Player> targets = new ArrayList<>(Bukkit.getOnlinePlayers());
                    briefingManager.enqueueDeployment(targets, mode);
                    sender.sendMessage(mm.deserialize("<gold>Memulai sekuens terjun mode <yellow>" + mode.name()
                            + " <gold>untuk <white>" + targets.size() + " <gold>pemain."));
                }
                case "reload" -> {
                    plugin.reloadConfig();
                    sender.sendMessage(mm.deserialize("<green>Konfigurasi config.yml berhasil dimuat ulang!"));
                }
                default -> sender.sendMessage(mm.deserialize("<red>Sub-command tidak dikenal."));
            }
            return true;
        }

        @Override
        public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                          @NotNull String alias, @NotNull String[] args) {
            if (args.length == 1) {
                return List.of("start", "setqueue", "setbriefing", "setcenter", "reload");
            }
            if (args.length == 2 && args[0].equalsIgnoreCase("start")) {
                return List.of("solo", "squad");
            }
            return List.of();
        }
    }
}
