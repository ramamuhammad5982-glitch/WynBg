package id.wynbg;

import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Transformation;
import org.jetbrains.annotations.NotNull;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;

public class WynBGPlugin extends JavaPlugin {

    public enum DropMode {
        SOLO,
        SQUAD
    }

    private ParachuteManager parachuteManager;
    private BriefingManager briefingManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.parachuteManager = new ParachuteManager(this);
        this.briefingManager = new BriefingManager(this, parachuteManager);

        getServer().getPluginManager().registerEvents(
                new DropListener(briefingManager, parachuteManager), this
        );

        WynBGCommand cmd = new WynBGCommand(this, briefingManager);
        if (getCommand("wynbg") != null) {
            getCommand("wynbg").setExecutor(cmd);
            getCommand("wynbg").setTabCompleter(cmd);
        }

        getLogger().info("WynBG (Solo/Squad Battleground Deployment) aktif di Paper 1.21.1!");
    }

    @Override
    public void onDisable() {
        if (briefingManager != null) {
            briefingManager.cleanup();
        }
        if (parachuteManager != null) {
            parachuteManager.cleanupAll();
        }
    }

    public Location getConfigLocation(String path) {
        String worldName = getConfig().getString(path + ".world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            world = Bukkit.getWorlds().getFirst();
        }
        double x = getConfig().getDouble(path + ".x", 0.5);
        double y = getConfig().getDouble(path + ".y", 100.0);
        double z = getConfig().getDouble(path + ".z", 0.5);
        float yaw = (float) getConfig().getDouble(path + ".yaw", 0.0);
        float pitch = (float) getConfig().getDouble(path + ".pitch", 0.0);
        return new Location(world, x, y, z, yaw, pitch);
    }

    public void saveConfigLocation(String path, Location loc) {
        getConfig().set(path + ".world", loc.getWorld().getName());
        getConfig().set(path + ".x", loc.getX());
        getConfig().set(path + ".y", loc.getY());
        getConfig().set(path + ".z", loc.getZ());
        getConfig().set(path + ".yaw", loc.getYaw());
        getConfig().set(path + ".pitch", loc.getPitch());
        saveConfig();
    }

    // =========================================================================
    // PARACHUTE MANAGER
    // =========================================================================
    private static class ParachuteManager {

        private final WynBGPlugin plugin;
        private final MiniMessage mm = MiniMessage.miniMessage();
        private final Set<UUID> parachutingPlayers = new HashSet<>();
        private final Set<UUID> landingGracePlayers = new HashSet<>();
        private final Map<UUID, ItemStack> savedChestplates = new HashMap<>();

        public ParachuteManager(WynBGPlugin plugin) {
            this.plugin = plugin;
            startLandingWatcher();
        }

        public void deployWithParachute(Player player, Location dropLocation) {
            UUID uuid = player.getUniqueId();
            player.teleport(dropLocation);
            player.setFallDistance(0f);

            ItemStack currentChest = player.getInventory().getChestplate();
            if (currentChest != null && currentChest.getType() != Material.AIR) {
                savedChestplates.put(uuid, currentChest.clone());
            }

            ItemStack parachute = new ItemStack(Material.ELYTRA);
            ItemMeta meta = parachute.getItemMeta();
            if (meta != null) {
                meta.displayName(mm.deserialize("<aqua><bold>Parasut Taktis"));
                meta.setUnbreakable(true);
                parachute.setItemMeta(meta);
            }

            player.getInventory().setChestplate(parachute);
            player.setGliding(true);
            parachutingPlayers.add(uuid);

            player.playSound(dropLocation, Sound.ITEM_ELYTRA_FLYING, 1.0f, 1.0f);
            player.sendActionBar(mm.deserialize("<aqua>Parasut terbuka! Arahkan pandangan untuk mendarat."));
        }

        private void startLandingWatcher() {
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (parachutingPlayers.isEmpty()) return;

                    Iterator<UUID> iterator = parachutingPlayers.iterator();
                    while (iterator.hasNext()) {
                        UUID uuid = iterator.next();
                        Player player = Bukkit.getPlayer(uuid);
                        if (player == null || !player.isOnline()) {
                            iterator.remove();
                            savedChestplates.remove(uuid);
                            continue;
                        }

                        if (player.isOnGround() || player.isInWater()) {
                            iterator.remove();
                            completeLanding(player);
                        }
                    }
                }
            }.runTaskTimer(plugin, 2L, 2L);
        }

        private void completeLanding(Player player) {
            UUID uuid = player.getUniqueId();
            player.setGliding(false);
            player.setFallDistance(0f);

            ItemStack previousChest = savedChestplates.remove(uuid);
            player.getInventory().setChestplate(previousChest);

            landingGracePlayers.add(uuid);
            Bukkit.getScheduler().runTaskLater(plugin, () -> landingGracePlayers.remove(uuid), 60L);

            player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 20, 0.4, 0.1, 0.4, 0.05);
            player.playSound(player.getLocation(), Sound.ENTITY_ARMOR_EQUIP_LEATHER, 1.0f, 1.1f);
            player.sendActionBar(mm.deserialize("<green><bold>MENDARAT! <gray>Segera cari perlengkapan."));
        }

        public boolean isParachuting(UUID uuid) {
            return parachutingPlayers.contains(uuid);
        }

        public boolean hasLandingGrace(UUID uuid) {
            return landingGracePlayers.contains(uuid);
        }

        public void cleanupPlayer(Player player) {
            UUID uuid = player.getUniqueId();
            if (parachutingPlayers.remove(uuid)) {
                player.getInventory().setChestplate(savedChestplates.remove(uuid));
            }
            landingGracePlayers.remove(uuid);
        }

        public void cleanupAll() {
            for (UUID uuid : new HashSet<>(parachutingPlayers)) {
                Player player = Bukkit.getPlayer(uuid);
                if (player != null) {
                    cleanupPlayer(player);
                }
            }
            parachutingPlayers.clear();
            savedChestplates.clear();
            landingGracePlayers.clear();
        }
    }

    // =========================================================================
    // BRIEFING & DEPLOYMENT MANAGER
    // =========================================================================
    private static class BriefingManager {

        private record QueuedBatch(List<UUID> playerIds, DropMode mode) {}

        private final WynBGPlugin plugin;
        private final ParachuteManager parachuteManager;
        private final MiniMessage mm = MiniMessage.miniMessage();

        private final Queue<QueuedBatch> waitingQueue = new LinkedList<>();
        private final Set<UUID> frozenPlayers = new HashSet<>();
        private final List<ItemDisplay> activeDisplays = new ArrayList<>();
        private boolean briefingOccupied = false;

        public BriefingManager(WynBGPlugin plugin, ParachuteManager parachuteManager) {
            this.plugin = plugin;
            this.parachuteManager = parachuteManager;
            startQueueNotifier();
        }

        public void enqueueDeployment(List<Player> players, DropMode mode) {
            List<UUID> ids = players.stream().map(Player::getUniqueId).toList();
            if (ids.isEmpty()) return;

            if (briefingOccupied) {
                Location queueLoc = plugin.getConfigLocation("locations.queue");
                for (Player p : players) {
                    p.teleport(queueLoc);
                    frozenPlayers.add(p.getUniqueId());
                }
                waitingQueue.add(new QueuedBatch(ids, mode));
            } else {
                runBriefingSession(ids, mode);
            }
        }

        private void startQueueNotifier() {
            new BukkitRunnable() {
                int dotStep = 0;

                @Override
                public void run() {
                    if (waitingQueue.isEmpty()) return;
                    dotStep = (dotStep % 3) + 1;
                    String dots = ".".repeat(dotStep);

                    int position = 1;
                    for (QueuedBatch batch : waitingQueue) {
                        Title title = Title.title(
                                mm.deserialize("<yellow><bold>MENUNGGU GILIRAN" + dots),
                                mm.deserialize("<gray>Antrean ke-<white>" + position + " <gray>| Ruang briefing sedang dipakai"),
                                Title.Times.times(Duration.ZERO, Duration.ofMillis(1200), Duration.ZERO)
                        );
                        for (UUID uuid : batch.playerIds()) {
                            Player p = Bukkit.getPlayer(uuid);
                            if (p != null && p.isOnline()) {
                                p.showTitle(title);
                            }
                        }
                        position++;
                    }
                }
            }.runTaskTimer(plugin, 20L, 20L);
        }

        private void runBriefingSession(List<UUID> playerIds, DropMode mode) {
            briefingOccupied = true;
            Location briefingLoc = plugin.getConfigLocation("locations.briefing");

            List<Player> participants = new ArrayList<>();
            for (UUID uuid : playerIds) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    participants.add(p);
                    frozenPlayers.add(uuid);
                    p.teleport(briefingLoc);
                    p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 35, 1, false, false));
                }
            }

            if (participants.isEmpty()) {
                finishBriefingAndAdvanceQueue();
                return;
            }

            spawnRotatingGear(briefingLoc);

            int deployAtSeconds = plugin.getConfig().getInt("briefing.deploy-at-seconds", 9);
            ConfigurationSection slidesSec = plugin.getConfig().getConfigurationSection("briefing.slides");

            new BukkitRunnable() {
                int elapsedSeconds = 0;

                @Override
                public void run() {
                    if (slidesSec != null) {
                        for (String key : slidesSec.getKeys(false)) {
                            int delay = slidesSec.getInt(key + ".delay-seconds", -1);
                            if (delay == elapsedSeconds) {
                                String rawTitle = slidesSec.getString(key + ".title", "");
                                String rawSub = slidesSec.getString(key + ".subtitle", "")
                                        .replace("{mode}", mode.name());
                                String soundName = slidesSec.getString(key + ".sound", "BLOCK_NOTE_BLOCK_PLING");
                                float pitch = (float) slidesSec.getDouble(key + ".pitch", 1.0);

                                Title title = Title.title(
                                        mm.deserialize(rawTitle),
                                        mm.deserialize(rawSub),
                                        Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(2), Duration.ofMillis(200))
                                );

                                Sound sound = parseSound(soundName);
                                for (Player p : participants) {
                                    if (!p.isOnline()) continue;
                                    p.showTitle(title);
                                    if (sound != null) {
                                        p.playSound(p.getLocation(), sound, 1.0f, pitch);
                                    }
                                }
                            }
                        }
                    }

                    if (elapsedSeconds >= deployAtSeconds) {
                        clearDisplays();
                        for (Player p : participants) {
                            frozenPlayers.remove(p.getUniqueId());
                        }
                        executeDeployment(participants, mode);
                        finishBriefingAndAdvanceQueue();
                        cancel();
                        return;
                    }

                    elapsedSeconds++;
                }
            }.runTaskTimer(plugin, 0L, 20L);
        }

        private void finishBriefingAndAdvanceQueue() {
            briefingOccupied = false;
            QueuedBatch next = waitingQueue.poll();
            if (next != null) {
                runBriefingSession(next.playerIds(), next.mode());
            }
        }

        private void executeDeployment(List<Player> players, DropMode mode) {
            Location center = plugin.getConfigLocation("locations.arena-center");
            World arenaWorld = center.getWorld();
            int spreadRadius = plugin.getConfig().getInt("deployment.spread-radius", 250);
            int minDistance = plugin.getConfig().getInt("deployment.min-spread-distance", 35);
            int heightOffset = plugin.getConfig().getInt("deployment.drop-height-offset", 120);

            List<int[]> usedAnchorCoords = new ArrayList<>();

            if (mode == DropMode.SOLO) {
                for (Player player : players) {
                    if (!player.isOnline()) continue;
                    findSafeCoordAsync(arenaWorld, center.getBlockX(), center.getBlockZ(), spreadRadius, minDistance, usedAnchorCoords, 0, safeLoc -> {
                        Location dropLoc = safeLoc.clone().add(0.5, heightOffset, 0.5);
                        parachuteManager.deployWithParachute(player, dropLoc);
                    });
                }
            } else {
                List<List<Player>> squads = buildSquads(players);
                double formationRadius = plugin.getConfig().getDouble("deployment.squad-formation-radius", 4.5);

                for (List<Player> squad : squads) {
                    findSafeCoordAsync(arenaWorld, center.getBlockX(), center.getBlockZ(), spreadRadius, minDistance, usedAnchorCoords, 0, anchorLoc -> {
                        int count = squad.size();
                        for (int i = 0; i < count; i++) {
                            Player member = squad.get(i);
                            if (!member.isOnline()) continue;

                            double angle = (2 * Math.PI * i) / Math.max(1, count);
                            double offsetX = (count == 1) ? 0.5 : Math.cos(angle) * formationRadius;
                            double offsetZ = (count == 1) ? 0.5 : Math.sin(angle) * formationRadius;

                            Location memberDropLoc = anchorLoc.clone().add(offsetX, heightOffset, offsetZ);
                            parachuteManager.deployWithParachute(member, memberDropLoc);
                        }
                    });
                }
            }
        }

        private List<List<Player>> buildSquads(List<Player> players) {
            int maxSquadSize = Math.max(1, plugin.getConfig().getInt("deployment.squad-size", 4));
            Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();

            Map<String, List<Player>> teamGroups = new LinkedHashMap<>();
            List<Player> unassigned = new ArrayList<>();

            for (Player p : players) {
                if (!p.isOnline()) continue;
                Team team = scoreboard.getEntryTeam(p.getName());
                if (team != null) {
                    teamGroups.computeIfAbsent(team.getName(), k -> new ArrayList<>()).add(p);
                } else {
                    unassigned.add(p);
                }
            }

            List<List<Player>> result = new ArrayList<>(teamGroups.values());
            Collections.shuffle(unassigned);

            for (int i = 0; i < unassigned.size(); i += maxSquadSize) {
                result.add(unassigned.subList(i, Math.min(i + maxSquadSize, unassigned.size())));
            }
            return result;
        }

        private void findSafeCoordAsync(World world, int centerX, int centerZ, int radius, int minDistance,
                                        List<int[]> usedCoords, int attemptCount, Consumer<Location> callback) {
            int x = centerX + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
            int z = centerZ + ThreadLocalRandom.current().nextInt(-radius, radius + 1);

            for (int attempt = 0; attempt < 15; attempt++) {
                boolean tooClose = false;
                for (int[] existing : usedCoords) {
                    double distSq = Math.pow(existing[0] - x, 2) + Math.pow(existing[1] - z, 2);
                    if (distSq < (double) minDistance * minDistance) {
                        tooClose = true;
                        break;
                    }
                }
                if (!tooClose) break;
                x = centerX + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
                z = centerZ + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
            }

            final int finalX = x;
            final int finalZ = z;

            world.getChunkAtAsync(finalX >> 4, finalZ >> 4).thenAccept(chunk -> {
                int highestY = world.getHighestBlockYAt(finalX, finalZ);
                Material surface = world.getBlockAt(finalX, highestY, finalZ).getType();
                Location candidate = new Location(world, finalX, highestY + 1.0, finalZ);

                if (attemptCount < 15 && (isUnsafeSurface(surface) || !world.getWorldBorder().isInside(candidate))) {
                    findSafeCoordAsync(world, centerX, centerZ, radius, minDistance, usedCoords, attemptCount + 1, callback);
                    return;
                }

                usedCoords.add(new int[]{finalX, finalZ});
                callback.accept(candidate);
            });
        }

        private boolean isUnsafeSurface(Material mat) {
            return mat == Material.WATER
                    || mat == Material.LAVA
                    || mat == Material.MAGMA_BLOCK
                    || mat == Material.FIRE
                    || mat == Material.CAMPFIRE
                    || mat == Material.CACTUS
                    || mat == Material.POWDER_SNOW
                    || mat.isAir();
        }

        private void spawnRotatingGear(Location center) {
            clearDisplays();
            World world = center.getWorld();
            double orbitRadius = plugin.getConfig().getDouble("briefing.orbit-radius", 3.8);
            List<String> itemNames = plugin.getConfig().getStringList("briefing.display-items");

            List<Material> materials = new ArrayList<>();
            for (String name : itemNames) {
                Material mat = Material.matchMaterial(name);
                if (mat != null && mat.isItem()) {
                    materials.add(mat);
                }
            }
            if (materials.isEmpty()) {
                materials.add(Material.TOTEM_OF_UNDYING);
            }

            int count = materials.size();
            for (int i = 0; i < count; i++) {
                double angle = (2 * Math.PI * i) / count;
                Location spawnLoc = center.clone().add(Math.cos(angle) * orbitRadius, 1.3, Math.sin(angle) * orbitRadius);

                Material itemMat = materials.get(i);
                ItemDisplay display = world.spawn(spawnLoc, ItemDisplay.class, entity -> {
                    entity.setItemStack(new ItemStack(itemMat));
                    entity.setBillboard(Display.Billboard.FIXED);
                    entity.setGlowing(true);
                });
                activeDisplays.add(display);
            }

            new BukkitRunnable() {
                float yaw = 0f;

                @Override
                public void run() {
                    if (activeDisplays.isEmpty()) {
                        cancel();
                        return;
                    }
                    yaw += 0.14f;
                    for (ItemDisplay display : activeDisplays) {
                        if (!display.isValid()) continue;
                        display.setInterpolationDelay(0);
                        display.setInterpolationDuration(2);
                        display.setTransformation(new Transformation(
                                new Vector3f(0f, 0f, 0f),
                                new AxisAngle4f(yaw, 0f, 1f, 0f),
                                new Vector3f(1.35f, 1.35f, 1.35f),
                                new AxisAngle4f(0f, 0f, 1f, 0f)
                        ));
                    }
                }
            }.runTaskTimer(plugin, 0L, 2L);
        }

        private Sound parseSound(String name) {
            try {
                return Sound.valueOf(name.toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                return null;
            }
        }

        private void clearDisplays() {
            activeDisplays.forEach(Display::remove);
            activeDisplays.clear();
        }

        public boolean isFrozen(UUID uuid) {
            return frozenPlayers.contains(uuid);
        }

        public void unfreeze(UUID uuid) {
            frozenPlayers.remove(uuid);
        }

        public void cleanup() {
            clearDisplays();
            frozenPlayers.clear();
            waitingQueue.clear();
            briefingOccupied = false;
        }
    }

    // =========================================================================
    // EVENT LISTENER
    // =========================================================================
    private static class DropListener implements Listener {

        private final BriefingManager briefingManager;
        private final ParachuteManager parachuteManager;

        public DropListener(BriefingManager briefingManager, ParachuteManager parachuteManager) {
            this.briefingManager = briefingManager;
            this.parachuteManager = parachuteManager;
        }

        @EventHandler
        public void onMove(PlayerMoveEvent event) {
            Player player = event.getPlayer();
            if (!briefingManager.isFrozen(player.getUniqueId())) return;

            if (event.getFrom().getX() != event.getTo().getX()
                    || event.getFrom().getY() != event.getTo().getY()
                    || event.getFrom().getZ() != event.getTo().getZ()) {
                Location locked = event.getFrom().clone();
                locked.setYaw(event.getTo().getYaw());
                locked.setPitch(event.getTo().getPitch());
                event.setTo(locked);
            }
        }

        @EventHandler
        public void onToggleGlide(EntityToggleGlideEvent event) {
            if (!(event.getEntity() instanceof Player player)) return;
            if (parachuteManager.isParachuting(player.getUniqueId()) && !event.isGliding() && !player.isOnGround()) {
                event.setCancelled(true);
            }
        }

        @EventHandler
        public void onArmorClick(InventoryClickEvent event) {
            if (!(event.getWhoClicked() instanceof Player player)) return;
            if (parachuteManager.isParachuting(player.getUniqueId()) && event.getSlot() == 38) {
                event.setCancelled(true);
            }
        }

        @EventHandler
        public void onDamage(EntityDamageEvent event) {
            if (!(event.getEntity() instanceof Player player)) return;
            if (briefingManager.isFrozen(player.getUniqueId())) {
                event.setCancelled(true);
                return;
            }
            if (parachuteManager.isParachuting(player.getUniqueId()) || parachuteManager.hasLandingGrace(player.getUniqueId())) {
                if (event.getCause() == EntityDamageEvent.DamageCause.FALL
                        || event.getCause() == EntityDamageEvent.DamageCause.FLY_INTO_WALL) {
                    event.setCancelled(true);
                }
            }
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent event) {
            Player player = event.getPlayer();
            briefingManager.unfreeze(player.getUniqueId());
            parachuteManager.cleanupPlayer(player);
        }
    }

    // =========================================================================
    // ADMIN COMMAND
    // =========================================================================
    private static class WynBGCommand implements CommandExecutor, TabCompleter {

        private final WynBGPlugin plugin;
        private final BriefingManager briefingManager;
        private final MiniMessage mm = MiniMessage.miniMessage();

        public WynBGCommand(WynBGPlugin plugin, BriefingManager briefingManager) {
            this.plugin = plugin;
            this.briefingManager = briefingManager;
        }

        @Override
        public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                                 @NotNull String label, @NotNull String[] args) {
            if (args.length == 0) {
                sender.sendMessage(mm.deserialize("<gold>WynBG <gray>» Gunakan <white>/wynbg <start|setqueue|setbriefing|setcenter|reload>"));
                return true;
            }

            String sub = args[0].toLowerCase(Locale.ROOT);
            switch (sub) {
                case "setqueue" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.queue", player.getLocation());
                    player.sendMessage(mm.deserialize("<green>Lokasi ruang antrean (Queue) berhasil disimpan!"));
                }
                case "setbriefing" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.briefing", player.getLocation());
                    player.sendMessage(mm.deserialize("<green>Lokasi ruang briefing (animasi item) berhasil disimpan!"));
                }
                case "setcenter" -> {
                    if (!(sender instanceof Player player)) return true;
                    plugin.saveConfigLocation("locations.arena-center", player.getLocation());
                    player.sendMessage(mm.deserialize("<green>Titik tengah arena Battleground berhasil disimpan!"));
                }
                case "start" -> {
                    DropMode mode = DropMode.SOLO;
                    if (args.length >= 2 && args[1].equalsIgnoreCase("squad")) {
                        mode = DropMode.SQUAD;
                    }
                    List<Player> targets = new ArrayList<>(Bukkit.getOnlinePlayers());
                    briefingManager.enqueueDeployment(targets, mode);
                    sender.sendMessage(mm.deserialize("<gold>Memulai sekuens terjun mode <yellow>" + mode.name()
                            + " <gold>untuk <white>" + targets.size() + " <gold>pemain."));
                }
                case "reload" -> {
                    plugin.reloadConfig();
                    sender.sendMessage(mm.deserialize("<green>Konfigurasi config.yml berhasil dimuat ulang!"));
                }
                default -> sender.sendMessage(mm.deserialize("<red>Sub-command tidak dikenal."));
            }
            return true;
        }

        @Override
        public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                          @NotNull String alias, @NotNull String[] args) {
            if (args.length == 1) {
                return List.of("start", "setqueue", "setbriefing", "setcenter", "reload");
            }
            if (args.length == 2 && args[0].equalsIgnoreCase("start")) {
                return List.of("solo", "squad");
            }
            return List.of();
        }
    }
}
